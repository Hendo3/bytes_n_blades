# Accessible dialog contract

All blocking overlays use `js/dialog-a11y.js` for one shared keyboard and focus contract.

## Required behavior

- The visible panel exposes `role="dialog"`, `aria-modal="true"`, an accessible title and, when applicable, a description.
- Focus moves inside the dialog when it opens.
- `Tab` and `Shift+Tab` cycle within the active dialog.
- Programmatic focus attempts outside the active dialog are redirected inside.
- `Escape` closes or cancels the dialog according to its action semantics.
- Closing restores focus to the control that opened the dialog when that control still exists.
- Stacked dialogs trap focus only in the topmost layer.

The controller is loaded before localization on every route and is included in the offline application shell. It governs the shared alert/confirm modal, global search, market comparator and Breach Protocol overlay.
