# Reproducibility restoration

Baseline: `bytes-and-blades-sem-rolagens-ui-jackout-fixo-2026-08-11.tar.gz`.

## Restored contracts

- Restored all six `localize:*` npm scripts documented by the README.
- Restored the distinction between the quick suite and the coverage suite.
- Restored mandatory coverage thresholds: 99% lines, 80% branches and 95% functions.
- Restored the complete README, catalog generators and regression suite in `fonte/`.

## Deterministic catalog generation

The generator regression test runs every generator twice in an isolated copy and
requires byte-for-byte equality with the committed canonical catalog after both
runs. It covers equipment, weapons, drugs, chips, cyberware, installation rules,
ammo and Netrunning.

The equipment generators now preserve the advanced modifier groups for fashion,
entertainment, housing and vehicles, including their bilingual mechanics, notes
and current housing keys.

## Final validation

- 122/122 tests passed in both quick and instrumented modes.
- 18 datasets validated.
- 68 static publishable files validated.
- Coverage: 99.55% lines, 80.72% branches and 96.46% functions.

The published UI remains identical to the baseline except for exposing the
existing ammo normalization helper from `bundles.js` for direct regression
testing. No catalog data changed after regeneration.
