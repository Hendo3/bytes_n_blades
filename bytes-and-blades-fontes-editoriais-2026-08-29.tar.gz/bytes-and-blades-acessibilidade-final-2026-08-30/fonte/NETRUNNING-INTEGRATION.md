# Bytes & Blades — Integração de Netrunning

Esta versão parte do `bytes-and-blades-prebuilt-cyberdecks-build.zip` e preserva as áreas de Cromo e Bundles sem alterações.

## Catálogo conectado

- 160 programas padrão exibidos inicialmente.
- 107 conversões opcionais de Netrunner, ativadas por opção explícita.
- 27 cyberdecks padrão exibidos inicialmente.
- 5 conversões opcionais de Netrunner, ativadas por opção explícita.
- 7 chassis e 21 opções no construtor de cyberdeck.
- 4 produtos de suporte para decks.

## Rotas

- `html/programs.html`: catálogo, busca, classe, preço máximo e conteúdo opcional.
- `html/cyberdecks.html`: cyberdecks publicados e suporte de bancada.
- `html/deck-builder.html`: configuração de hardware e carga de programas com limite de MU.

As três rotas possuem navegação direta entre si. Programas, decks publicados, suporte e decks personalizados são enviados ao mesmo carrinho da loja. O carrinho preserva configuração, programas carregados e nomes localizados.

## Escopo

Software de Fortaleza pode aparecer como produto comercial quando a ficha permite, mas nunca entra no construtor de cyberdeck. Não existe construtor de Fortaleza.

## Áreas protegidas

Os seguintes arquivos permanecem idênticos ao prebuilt recebido:

- `js/bundles.js`
- `html/bundles.html`
- `js/script.js`
- `js/core-utils.js`
- `js/chip-rates.js`
- `html/cyberwares.html`
- `data/cyberwares.json`
- `data/cyberwares.pt-BR.json`
- `data/equipment.json`
- `data/equipment.pt-BR.json`

