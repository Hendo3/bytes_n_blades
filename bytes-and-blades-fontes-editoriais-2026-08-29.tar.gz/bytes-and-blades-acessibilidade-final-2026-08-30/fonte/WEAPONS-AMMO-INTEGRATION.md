# Weapons / Ammo Integration

Canonical base: `bytes-and-blades-ui-cyberpunk-global-2026-08-11.tar.gz`.

## Sources

- `Weapons(1).pdf`: Cyberpunk 2020 Weapon Listing, revision 2001-12-04.
- `ammos-addons(1).pdf`: Cyberpunk 2020 Ammo & Add-ons, revision 1998-11-25.

## Result

- `weapons.json` and `weapons.pt-BR.json`: 184 weapon records and no ammunition records.
- The apparent missing weapons in the extracted source JSON were spelling errors. The corrected records were already present; no duplicate typo variants were created.
- `ammo.json` and `ammo.pt-BR.json`: 336 unique records.
- Compact source cross-references for IMI 25mm and 30mm grenades were expanded into individual catalog records.
- Ammunition reloads preserve the old ammo-box IDs through `legacyIds`, keeping existing carts and Bundle selection compatible.
- Multiplier-priced bullet types are applied to a base reload in the UI. Entries with no published fixed price remain reference-only instead of being sold for zero.

## Validation

- JSON Schema validation covers 18 datasets.
- 14 tests cover separation, source families, aliases, ammunition pricing, Cyberware preservation and Netrunning regressions.
- The static build contains 68 files.
