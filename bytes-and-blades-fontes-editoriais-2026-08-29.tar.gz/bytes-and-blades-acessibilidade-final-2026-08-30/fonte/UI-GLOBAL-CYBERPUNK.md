# Bytes & Blades — UI Cyberpunk Global

Esta distribuição aplica o sistema visual dos controles do builder de cyberdecks a todo o site.

## Controles abrangidos

- selects com moldura de terminal e indicador próprio;
- checkboxes como toggles neon;
- radios como seletores luminosos angulares;
- inputs de texto, busca, senha e e-mail com painel de hardware;
- inputs numéricos convertidos em steppers `− / +`;
- controles criados dinamicamente por catálogos e geradores;
- estados de hover, foco por teclado, desabilitado e responsividade móvel.

## Preservação funcional

- IDs, nomes, valores e eventos dos campos originais são mantidos;
- lógica de Cromo e Bundles não foi alterada;
- lógica e catálogos de Netrunning não foram alterados;
- HTML, CSS e JavaScript permanecem Vanilla;
- não foram adicionadas APIs, frameworks ou dependências de produção.

## Conteúdo

- `publicar/`: site estático pronto para publicação;
- `fonte/`: fonte, dados, schemas, scripts e testes.

## Validação

- 9 testes funcionais aprovados;
- 16 datasets validados;
- 64 arquivos no build estático.
