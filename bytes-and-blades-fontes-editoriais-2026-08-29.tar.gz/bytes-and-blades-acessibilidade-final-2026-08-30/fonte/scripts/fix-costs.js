#!/usr/bin/env node
/** Normalize legacy `cost` fields in the canonical cyberware dataset. */

const fs = require("node:fs");
const path = require("node:path");

const dataFile = path.resolve(__dirname, "../data/cyberwares.json");

function adjustCost(value) {
  if (Array.isArray(value)) {
    value.forEach(adjustCost);
    return;
  }
  if (!value || typeof value !== "object") return;

  Object.entries(value).forEach(([key, child]) => {
    if (key !== "cost") {
      adjustCost(child);
      return;
    }

    if (typeof child === "number") {
      value[key] = child.toFixed(1);
      return;
    }
    if (typeof child !== "string") return;

    const parsed = Number.parseFloat(child);
    const stripped = Number.parseFloat(child.replace(/[^0-9.-]+/g, ""));
    const normalized = Number.isNaN(parsed) ? stripped : parsed;
    if (Number.isNaN(normalized)) {
      console.log(`Invalid value found in ${key}: ${child}`);
      return;
    }
    value[key] = normalized.toFixed(1);
  });
}

function verifyCost(value, currentPath = []) {
  if (Array.isArray(value)) {
    return value.flatMap((item, index) => verifyCost(item, currentPath.concat(`[${index}]`)));
  }
  if (!value || typeof value !== "object") return [];

  return Object.entries(value).flatMap(([key, child]) => {
    const childPath = currentPath.concat(key);
    if (key !== "cost") return verifyCost(child, childPath);
    const validString = typeof child === "string"
      && /^\d+(?:\.\d)?0$/.test(child)
      && !/[^\d.]/.test(child);
    return typeof child === "number" || !validString
      ? [{ path: childPath.join("."), value: child }]
      : [];
  });
}

const data = JSON.parse(fs.readFileSync(dataFile, "utf8"));
console.log("Cost errors found:", verifyCost(data));
adjustCost(data);
fs.writeFileSync(dataFile, `${JSON.stringify(data, null, 4)}\n`);
console.log(`Normalized legacy cost fields in ${dataFile}`);
