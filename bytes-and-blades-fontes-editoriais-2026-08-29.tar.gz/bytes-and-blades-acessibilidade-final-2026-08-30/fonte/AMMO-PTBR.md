# Tradução completa de munições

O catálogo `ammo.pt-BR.json` agora é gerado integralmente em português
brasileiro a partir da mesma fonte mecânica de `ammo.json`.

## Cobertura da tradução

- 336 registros.
- 26 categorias localizadas.
- 286 nomes traduzidos; os demais são siglas, fórmulas ou nomes próprios.
- 315 efeitos traduzidos; os demais são fórmulas puramente numéricas.
- 122 campos de compatibilidade traduzidos.
- Descrições, título, fonte e indicação de preço não informado localizados.

IDs, preços, multiplicadores, limites, aliases e demais campos mecânicos
permanecem idênticos ao catálogo inglês.

## Regeneração

```bash
npm run localize:ammo:pt-BR
```

O comando também faz parte de `npm run localize:pt-BR`. O teste de build executa
o gerador duas vezes em uma cópia isolada e exige igualdade byte a byte com o
catálogo canônico em ambas as execuções.

## Validação

- 124/124 testes.
- 18 datasets válidos.
- 68 arquivos publicados.
- Cobertura: 99,55% linhas, 80,76% ramos e 96,46% funções.
