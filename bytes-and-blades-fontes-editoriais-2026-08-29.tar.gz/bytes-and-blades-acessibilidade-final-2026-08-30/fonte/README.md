# Byte & Blades

Editorial book/page metadata is maintained separately from mechanical data in `data/editorial-sources.json`. See `EDITORIAL-SOURCES.md` for verification states and the rule that unofficial compilations are inventory-only.

Blocking overlays share the keyboard and focus contract documented in `ACCESSIBILITY-DIALOGS.md`: complete ARIA naming, focus containment, `Escape` handling and focus restoration.

Loja estática bilíngue para campanhas de **Cyberpunk 2020**, apresentada como um DataTerm fora da rede. O site reúne ciberware, equipamentos, armas, munições, drogas, chips de perícia e pacotes prontos sem depender de backend ou banco de dados.

## Recursos

- Interface completa em `en-US` e `pt-BR`, com idioma persistido entre páginas e sessões.
- Busca global bilíngue em 1.584 sinais de mercado, acessível por `Ctrl+K` ou `/`.
- Comparador persistente para duas ou três armas, peças de ciberware, programas ou cyberdecks da mesma família.
- Links permanentes para itens configurados, filtros de mercado e cyberdecks montados no builder.
- Navegação global agrupada por mercados, Netrunning e ferramentas, com ações de sessão sempre visíveis.
- Catálogos de ciberware, equipamentos, armas, munições, drogas e chips de perícia.
- Filtros por categoria e atributos específicos de cada catálogo.
- Carrinho persistente em `localStorage`, com preço, Perda de Humanidade, avisos de consistência e exportação em JSON.
- Cofre local de loadouts nomeados, com salvar, carregar, importar e exportar JSON.
- Painel inicial com resumo do loadout ativo e diretório completo dos mercados.
- Pacotes gerados com validação de dependências, provedores, capacidades e slots.
- Forja de drogas baseada nas tabelas de criação do sistema.
- Minigame de invasão do carrinho, login local por handle e console de diagnóstico.
- PWA realmente offline, com service worker, shell completo e os 18 datasets bilíngues em cache.
- Tipografia Mokoto incorporada localmente, sem dependência de fontes externas.
- Schemas JSON, validação de build e suíte automatizada com limites obrigatórios de cobertura.

## Requisitos

- Node.js `20.19.0` ou superior dentro da linha 20, ou `22.12.0` ou superior.
- npm.
- Python 3 para os scripts de restauração e localização.
- Um navegador moderno.

O Node.js é usado apenas no desenvolvimento, nos testes e na geração do build. O site publicado é composto somente por arquivos estáticos.

## Início rápido

Instale as dependências:

```bash
npm ci
```

Inicie o servidor de desenvolvimento:

```bash
npm run dev
```

Abra o endereço exibido pelo Vite. A entrada normal da aplicação é `login.html`.

Nenhuma conta é criada e nenhum dado é enviado a um servidor: o handle, o idioma e o carrinho permanecem no armazenamento local do navegador.

## Fluxo do DataTerm

- `Ctrl+K` ou `/` abre a busca global em qualquer página autenticada.
- A busca não ocupa espaço no cabeçalho; na home, ela também pode ser aberta pelo console central.
- Os resultados apontam diretamente para o item no catálogo correspondente.
- `COPY ITEM LINK` preserva opções do item, como nível de chip, munição, SmartChip e modificador de preço.
- `COPY FILTER LINK` preserva a consulta, categoria, faixa de preço e filtros específicos do mercado.
- `COPY BUILD LINK` preserva chassi, componentes, opções, programas e conteúdo opcional do cyberdeck.
- O cabeçalho usa a mesma arquitetura em todas as rotas: `Mercados`, `Netrunning` e `Ferramentas` abrem grupos próprios, sem acrescentar mais links soltos.
- Carrinho, contador de itens, idioma e `JACK OUT` ficam numa faixa de sessão independente dos grupos de conteúdo.
- O botão `COMPARE` dos catálogos mantém até três itens do mesmo feed durante a navegação e abre uma matriz sem rolagem horizontal da página.
- A página inicial resume quantidade, custo, Perda de Humanidade e loadouts salvos.
- O carrinho permite ajustar a quantidade de cada linha sem alterar quantidades mecânicas internas de Bundles ou equipamentos de Netrunning.
- Loadouts nomeados são armazenados somente no dispositivo atual.
- Arquivos exportados podem ser importados novamente ou trocados com outros jogadores.
- Em telas estreitas, os grupos passam para a própria altura do cabeçalho e nunca criam rolagem horizontal.

## Operação offline

Na primeira visita online, `service-worker.js` instala atomicamente o shell da aplicação, todas as rotas de mercado, fontes, ícones, controladores e os 18 datasets EN-US/PT-BR. Depois disso:

- páginas e links permanentes continuam abrindo sem rede;
- catálogos, chips, Bundles, busca, carrinho e builder usam os dados armazenados;
- navegações desconhecidas recebem a rota 404 local;
- arquivos em cache são atualizados em segundo plano quando a conexão retorna;
- versões antigas do cache são removidas somente após a nova versão terminar de instalar;
- carrinho, idioma e loadouts continuam em `localStorage` e não são apagados por atualizações da PWA.

O registro exige HTTPS ou `localhost`, conforme as regras de segurança dos navegadores para service workers.

## Build de produção

Gere e valide a versão publicável:

```bash
npm run build
npm run validate
```

O resultado será criado em `dist/`. Para testá-lo localmente:

```bash
python3 -m http.server 8000 --directory dist
```

Depois, acesse `http://localhost:8000/login.html`.

O build copia os arquivos estáticos necessários sem modificar os datasets de origem. O conteúdo de `dist/` é gerado e não deve ser editado diretamente.

## Tipografia

As fontes ficam em `assets/fonts/` e são carregadas por `css/styles.css`:

- `Mokoto Glitch`: corpo, descrições e conteúdo corrido;
- `Mokoto Glitch Mark`: títulos, menus, controles e metadados de interface.

As duas declarações usam `font-display: swap` e uma pilha monoespaçada de fallback para caracteres não presentes nos arquivos.

## Localização

O catálogo `en-US` é a fonte mecânica do projeto. As versões `pt-BR` preservam os mesmos IDs, preços, estatísticas, dependências e slots, alterando apenas o conteúdo visível.

Para regenerar todos os datasets brasileiros:

```bash
npm run localize:pt-BR
```

Também é possível regenerar um catálogo isoladamente:

```bash
npm run localize:cyberware:pt-BR
npm run localize:equipment:pt-BR
npm run localize:weapons:pt-BR
npm run localize:ammo:pt-BR
npm run localize:drugs:pt-BR
npm run localize:chips:pt-BR
```

No português brasileiro, a categoria editorial `APTR` é exibida como `PART`. A chave interna continua sendo `aptr` para preservar URLs, carrinho e compatibilidade entre idiomas.

Ao alterar um catálogo:

1. Edite a versão inglesa e mantenha os IDs estáveis.
2. Atualize a memória ou o script de localização correspondente.
3. Execute `npm run localize:pt-BR`.
4. Confirme a equivalência mecânica com `npm run test:all`.

## Dados e schemas

| Catálogo | EN-US | PT-BR | Schema |
| --- | --- | --- | --- |
| Ciberware | `data/cyberwares.json` | `data/cyberwares.pt-BR.json` | `data/cyberwares.schema.json` |
| Equipamentos | `data/equipment.json` | `data/equipment.pt-BR.json` | `data/equipment.schema.json` |
| Armas | `data/weapons.json` | `data/weapons.pt-BR.json` | `data/weapons-store.schema.json` |
| Munições e add-ons | `data/ammo.json` | `data/ammo.pt-BR.json` | — |
| Drogas | `data/drugs.json` | `data/drugs.pt-BR.json` | `data/drugs.schema.json` |
| Chips de perícia | `data/chip-rates.json` | `data/chip-rates.pt-BR.json` | `data/chip-rates.schema.json` |
| Programas | `data/programs.json` | `data/programs.pt-BR.json` | — |
| Cyberdecks | `data/cyberdecks.json` | `data/cyberdecks.pt-BR.json` | — |

Os schemas e os testes verificam tanto a validade individual dos arquivos quanto a equivalência estrutural e mecânica entre os idiomas.

## Testes e validação

O gate completo do projeto é:

```bash
npm run test:all
```

Esse comando executa:

1. verificação de sintaxe de todos os scripts;
2. validação dos datasets por schema;
3. testes funcionais e de integridade;
4. geração do build estático;
5. validação dos arquivos publicados;
6. suíte instrumentada de cobertura.

Os limites mínimos obrigatórios são:

- 99% das linhas;
- 80% dos ramos;
- 95% das funções.

Comandos auxiliares:

| Comando | Finalidade |
| --- | --- |
| `npm run check` | Sintaxe, datasets e testes rápidos |
| `npm run test:quick` | Testes sem instrumentação de cobertura |
| `npm test` | Testes com os limites obrigatórios de cobertura |
| `npm run build` | Gera `dist/` |
| `npm run validate` | Valida a estrutura e as referências do build |
| `npm run test:all` | Executa o gate completo |

## Estrutura do projeto

```text
assets/       Fontes, ícones e recursos visuais
css/          Identidade visual e layout
data/         Catálogos bilíngues e schemas JSON
html/         Catálogos, carrinho, pacotes e ferramentas
js/           Interface, regras do carrinho, i18n e validações
scripts/      Restauração, localização, build e validação
tests/        Testes de dados, componentes e fluxos do site
dist/         Build estático gerado
index.html    Página inicial
login.html    Entrada da aplicação
```

## Contribuição

Antes de abrir um pull request:

- não altere IDs existentes sem uma migração explícita;
- mantenha as versões `en-US` e `pt-BR` mecanicamente equivalentes;
- não edite arquivos em `dist/` manualmente;
- execute `npm run test:all` e inclua o resultado na descrição do PR.

## Licença e direitos

O código próprio do projeto é distribuído sob a licença [MIT](LICENSE).

Este é um projeto de fã, sem afiliação oficial. **Cyberpunk 2020** e o material de jogo relacionado pertencem aos respectivos detentores de direitos e não são licenciados pela MIT.
