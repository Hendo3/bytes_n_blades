# Tipografia Mokoto

## Aplicação

- Corpo, descrições e conteúdo corrido: `Mokoto Glitch`.
- Títulos, menus, navegação, botões, labels, selects, tabelas e status de interface: `Mokoto Glitch Mark`.
- Carregamento local por `@font-face`, com `font-display: swap`.
- Fallback: `Share Tech Mono`, `Courier New` e `monospace`.

## Arquivos

| Arquivo | SHA-256 |
| --- | --- |
| `assets/fonts/Mokoto Glitch.ttf` | `4ce53a09cc98a14b6976f6dff177a8bba1948bc66540ef3653b99eb49f30caca` |
| `assets/fonts/Mokoto Glitch Mark.ttf` | `d0578bdae906b599a7b7dbb4c5ed3bcb5b47514d9a5cfd67e5ee29a5a9bec05f` |

## Limites conhecidos

Os arquivos fornecidos não contêm `Ç` maiúsculo, o sinal de menos matemático `−` nem o sinal de multiplicação `×`. Nesses três glifos, o navegador usa automaticamente a fonte de fallback; nenhum texto ou valor é substituído.

## Proteção contra regressão

`tests/ui-regressions.test.js` verifica os hashes dos arquivos, as duas declarações `@font-face`, a distribuição entre corpo e interface e a ausência de regras diretas com `font-family: monospace`.
