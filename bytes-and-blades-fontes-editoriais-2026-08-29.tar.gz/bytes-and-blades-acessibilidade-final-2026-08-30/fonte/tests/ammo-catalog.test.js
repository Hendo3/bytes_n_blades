const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { afterEach, test } = require("node:test");
const {
  installBrowserEnv, requireFresh, dispatchDOMContentLoaded, jsonResponse, flushPromises,
} = require("./helpers/browser-env.js");

const root = path.resolve(__dirname, "..");
const readJson = (file) => JSON.parse(fs.readFileSync(path.join(root, file), "utf8"));
const cleanups = [];
afterEach(() => { while (cleanups.length) cleanups.pop()(); });

test("weapons and ammunition are separate catalogs", () => {
  for (const locale of ["", ".pt-BR"]) {
    const weapons = readJson(`data/weapons${locale}.json`).weapons;
    const ammo = readJson(`data/ammo${locale}.json`).items;
    assert.equal(weapons.length, 184);
    assert.equal(weapons.some((item) => /ammo|muni/i.test(`${item.class} ${item.type_code}`)), false);
    assert.equal(ammo.length, 336);
    assert.equal(new Set(ammo.map((item) => item.id)).size, ammo.length);
  }
});

test("localizes every visible ammunition field without changing mechanics", () => {
  const englishEnvelope = readJson("data/ammo.json");
  const localizedEnvelope = readJson("data/ammo.pt-BR.json");
  const english = englishEnvelope.items;
  const localized = localizedEnvelope.items;
  const visibleFields = new Set(["category", "name", "effect", "description", "compatibility", "price_label"]);
  const englishResidue = /\b(?:and|or|for|from|with|through|only|while|over|then|by|beyond|plus|damage|range|pattern|radius|area|armor|soft|hard|shell|grenade|weapon|weapons|shot|shots|fire|smoke|gas|blind|blinded|deaf|escape|roll|requires|cost|price|not|listed|each|one|two|three|half|light|medium|heavy|extreme|stun|awareness|reliability|concealability|option|options|space|spaces|level|levels|automatic|launcher|low|cased|caseless|effect|effects|available|body|wrap|catch|throw|penetrating|penetration|fragmentation|disorient|disorientation|aimed|attack|fixed|braced|stationary|extra|aiming|poor|standard|payload|pellets|needles|ball|cloud|finish|pictures|digital|badge|built|integrated|sight|battery|fitting|rifle|pistol|fumble|burst|barrel|mount|movement|penalties|darkness|completely|silent|self|bow|drug|rare|illegal|shatter|shatters|ceramic|heart|location|minimum)\b/i;

  assert.equal(localizedEnvelope.locale, "pt-BR");
  assert.match(localizedEnvelope.source, /revisão/);
  assert.equal(localized.length, 336);
  let translatedNames = 0;
  let translatedEffects = 0;

  english.forEach((entry, index) => {
    const pt = localized[index];
    assert.equal(pt.id, entry.id);
    assert.equal(pt.description, pt.effect);
    assert.doesNotMatch(`${pt.effect} ${pt.compatibility || ""}`, englishResidue, entry.id);
    if (pt.name !== entry.name) translatedNames += 1;
    if (pt.effect !== entry.effect) translatedEffects += 1;

    for (const [key, value] of Object.entries(entry)) {
      if (visibleFields.has(key)) continue;
      assert.deepEqual(pt[key], value, `${entry.id}.${key}`);
    }
    if (entry.price_label && entry.price_label !== "Price not listed") {
      assert.equal(pt.price_label, entry.price_label, `${entry.id}.price_label`);
    }
  });

  assert.ok(translatedNames >= 280, `${translatedNames} names translated`);
  assert.ok(translatedEffects >= 300, `${translatedEffects} effects translated`);
  assert.equal(new Set(localized.map((entry) => entry.category)).size, 26);
  assert.equal(localized.some((entry) => entry.price_label === "Price not listed"), false);
});

test("includes every family from Ammo & Add-ons", () => {
  const ammo = readJson("data/ammo.json").items;
  const categories = new Set(ammo.map((item) => item.category));
  for (const required of [
    "Ammunition Reloads", "Ammunition Types", "12 Gauge", "Hand Grenades",
    "Militech 25mm Grenades", "40mm Launched Grenades", "Rifle Grenades",
    "Special Projectiles", "Rocket and Missile Reloads", "Arrowheads",
    "Firearm Accessories", "Bow Accessories", "Melee Accessories", "Gun Customization",
  ]) assert.ok(categories.has(required), required);
});

test("preserves old bundle ammo ids as aliases", () => {
  const ammo = readJson("data/ammo.json").items;
  const aliases = new Set(ammo.flatMap((item) => item.legacyIds || []));
  for (const id of [
    "weapon_light_handgun_light_smg_ammo_box_100",
    "weapon_medium_handgun_medium_smg_ammo_box_100",
    "weapon_heavy_handgun_heavy_smg_ammo_box_100",
    "weapon_very_heavy_handgun_ammo_box_100",
    "weapon_assault_rifle_ammo_box_100",
  ]) assert.ok(aliases.has(id), id);
});

test("ships the dedicated page and navigation", () => {
  const ammoPage = fs.readFileSync(path.join(root, "html/ammo.html"), "utf8");
  const weaponsPage = fs.readFileSync(path.join(root, "html/weapons.html"), "utf8");
  assert.match(ammoPage, /data\/ammo\.json|js\/script\.js/);
  assert.match(weaponsPage, /href="\.\/ammo\.html"/);
});

test("renders ammo separately and prices bullet types against a base reload", async () => {
  const browser = installBrowserEnv({
    url: "https://bytes.test/html/ammo.html",
    html: "<div id='category-list'></div><h1 id='title-category'></h1><div id='items-list'></div><select id='fs-category'></select><button id='fs-apply'></button><button id='fs-clear'></button>",
    fetchImpl: async () => jsonResponse(readJson("data/ammo.json")),
  });
  cleanups.push(browser.cleanup);
  window.I18n = { getLocale: () => "en-US", dataPath: (value) => value, t: (_key, _params, fallback) => fallback };
  global.Modal = { alert() {} };
  cleanups.push(() => { delete global.Modal; });
  requireFresh("js/script.js");
  dispatchDOMContentLoaded(document);
  await flushPromises(6);
  assert.equal(document.getElementById("title-category").textContent, "Ammunition Reloads");
  const options = document.querySelector(".item select");
  assert.ok(options);
  assert.ok(options.options.length >= 20);
  options.value = [...options.options].find((option) => option.textContent.includes("Armor Piercing"))?.value;
  options.dispatchEvent(new window.Event("change", { bubbles: true }));
  assert.match(document.querySelector(".item strong").textContent, /45/);
});

test("renders the localized ammunition catalog on the pt-BR route", async () => {
  const requests = [];
  const browser = installBrowserEnv({
    url: "https://bytes.test/html/ammo.html",
    html: "<div id='category-list'></div><h1 id='title-category'></h1><div id='items-list'></div><select id='fs-category'></select><button id='fs-apply'></button><button id='fs-clear'></button>",
    fetchImpl: async (url) => {
      requests.push(String(url));
      return jsonResponse(readJson("data/ammo.pt-BR.json"));
    },
  });
  cleanups.push(browser.cleanup);
  window.I18n = {
    getLocale: () => "pt-BR",
    dataPath: (value) => value.replace(".json", ".pt-BR.json"),
    t: (_key, _params, fallback) => fallback,
  };
  global.Modal = { alert() {} };
  cleanups.push(() => { delete global.Modal; });
  requireFresh("js/script.js");
  dispatchDOMContentLoaded(document);
  await flushPromises(6);

  assert.ok(requests.length >= 1);
  assert.ok(requests.every((url) => url === "../data/ammo.pt-BR.json"));
  assert.equal(document.getElementById("title-category").textContent, "Recargas de Munição");
  assert.match(document.getElementById("items-list").textContent, /Pistola Leve e Submetralhadora/);
  assert.match(document.getElementById("items-list").textContent, /Recarga padrão, 100 cartuchos/);
});

test("keeps multiplier-only ammunition types as reference entries", async () => {
  const browser = installBrowserEnv({
    url: "https://bytes.test/html/ammo.html",
    html: "<div id='category-list'></div><h1 id='title-category'></h1><div id='items-list'></div><select id='fs-category'></select><button id='fs-apply'></button><button id='fs-clear'></button>",
    fetchImpl: async () => jsonResponse(readJson("data/ammo.json")),
  });
  cleanups.push(browser.cleanup);
  window.I18n = { getLocale: () => "en-US", dataPath: (value) => value, t: (_key, _params, fallback) => fallback };
  global.Modal = { alert() {} };
  cleanups.push(() => { delete global.Modal; });
  requireFresh("js/script.js");
  dispatchDOMContentLoaded(document);
  await flushPromises(6);

  const ammunitionTypes = [...document.querySelectorAll("#category-list button")]
    .find((button) => button.textContent.includes("AMMUNITION TYPES"));
  assert.ok(ammunitionTypes);
  ammunitionTypes.click();
  const referenceButton = document.querySelector("#items-list .btn-add");
  assert.equal(referenceButton.disabled, true);
  assert.match(referenceButton.textContent, /REFERENCE/);
});
