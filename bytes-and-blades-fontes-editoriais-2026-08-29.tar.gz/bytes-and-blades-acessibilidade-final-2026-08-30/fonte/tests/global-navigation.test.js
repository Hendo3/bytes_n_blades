const assert = require("node:assert/strict");
const { afterEach, describe, test } = require("node:test");

const {
  installBrowserEnv,
  requireFresh,
  dispatchDOMContentLoaded,
} = require("./helpers/browser-env.js");

const cleanups = [];

function useBrowser(options = {}) {
  const browser = installBrowserEnv({
    url: "https://bytes.test/html/weapons.html",
    html: `<!doctype html><html><head></head><body>
      <header class="navbar">
        <div class="logo-area"><h1 class="logo">Byte & Blades</h1><p class="tagline"></p></div>
        <nav aria-label="Main Navigation">
          <ul class="nav-links"><li><a href="../index.html">Legacy</a></li></ul>
          <div class="language-selector"><label>Language</label><select><option>en-US</option></select></div>
        </nav>
      </header>
    </body></html>`,
    ...options,
  });
  cleanups.push(browser.cleanup);
  return browser;
}

function installI18n(translations = {}) {
  const api = {
    t: (key, params, fallback) => String(translations[key] || fallback)
      .replace(/\{(\w+)\}/g, (_match, name) => params?.[name] ?? `{${name}}`),
  };
  window.I18n = api;
  global.I18n = api;
  return api;
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  for (const name of ["CyberNavigation", "I18n", "Modal"]) delete global[name];
});

describe("unified DataTerm navigation", () => {
  test("replaces every legacy header with grouped routes and persistent controls", () => {
    const { document } = useBrowser();
    installI18n();
    localStorage.setItem("cyber_cart", JSON.stringify([
      { id: "gun", cartCount: 2 },
      { id: "ammo" },
    ]));
    const navigation = requireFresh("js/global-navigation.js");
    dispatchDOMContentLoaded(document);

    const nav = document.querySelector(".global-navigation");
    assert.ok(nav);
    assert.equal(nav.dataset.unifiedNavigation, "true");
    assert.equal(document.querySelectorAll(".global-nav-groups > li").length, 5);
    assert.equal(document.querySelectorAll(".global-nav-cluster").length, 3);
    assert.equal(document.querySelectorAll(".global-nav-menu a").length, 13);
    assert.ok(document.querySelector(".global-nav-cluster--markets.is-current"));
    assert.equal(document.querySelector('[data-nav-route="weapons.html"]').getAttribute("aria-current"), "page");
    assert.equal(document.querySelector(".global-nav-cart-count").textContent, "3");
    assert.equal(document.querySelector(".global-nav-cart-link").getAttribute("aria-label"), "Cart, 3 items");
    assert.ok(document.querySelector(".global-nav-controls .language-selector"));
    assert.equal(nav.textContent.includes("SEARCH"), false);
    assert.equal(navigation.currentFile(), "weapons.html");
    assert.match(navigation.route("index.html"), /\/index\.html$/);
    assert.match(navigation.route("programs.html"), /\/html\/programs\.html$/);

    assert.equal(navigation.boot(), nav);
    assert.equal(document.querySelectorAll(".global-navigation").length, 1);
  });

  test("updates the cart signal and closes grouped menus accessibly", () => {
    const { document, window } = useBrowser();
    installI18n();
    const navigation = requireFresh("js/global-navigation.js");
    dispatchDOMContentLoaded(document);

    assert.equal(navigation.cartCount({ getItem: () => "broken" }), 0);
    assert.equal(navigation.cartCount({ getItem: () => "{}" }), 0);
    localStorage.setItem("cyber_cart", JSON.stringify([{ id: "deck", cartCount: 4 }]));
    window.dispatchEvent(new window.Event("stash-updated"));
    assert.equal(document.querySelector(".global-nav-cart-count").textContent, "4");

    const [market, netrunning] = document.querySelectorAll(".global-nav-cluster details");
    market.open = true;
    market.dispatchEvent(new window.Event("toggle"));
    netrunning.open = true;
    netrunning.dispatchEvent(new window.Event("toggle"));
    assert.equal(market.open, false);
    assert.equal(netrunning.open, true);

    document.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.equal(netrunning.open, false);
    assert.equal(document.activeElement, netrunning.querySelector("summary"));

    market.open = true;
    document.body.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    assert.equal(market.open, false);
  });

  test("keeps JACK OUT alive when auth boots before navigation", () => {
    const { document } = useBrowser({ url: "https://bytes.test/html/aptr-chips.html" });
    installI18n();
    localStorage.setItem("cyber_runner_id", "RUNNER");
    global.Modal = { confirm() {} };
    requireFresh("js/auth.js");
    requireFresh("js/global-navigation.js");
    dispatchDOMContentLoaded(document);

    assert.equal(document.querySelectorAll(".jack-out-link").length, 1);
    assert.ok(document.querySelector(".nav-session-links .jack-out-link"));
    assert.equal(document.querySelector(".nav-session-links").children.length, 2);
  });

  test("uses localized navigation labels without translating route identity", () => {
    const { document } = useBrowser({ url: "https://bytes.test/html/deck-builder.html" });
    installI18n({
      "nav.home": "Início",
      "nav.markets": "Mercados",
      "nav.deck_builder": "Montar um Cyberdeck",
      "nav.cart_count": "Carrinho, {count} itens",
    });
    requireFresh("js/global-navigation.js");
    dispatchDOMContentLoaded(document);

    assert.equal(document.querySelector(".global-nav-home a").textContent, "Início");
    assert.equal(document.querySelector(".global-nav-cluster--markets summary").textContent, "Mercados");
    assert.equal(document.querySelector('[data-nav-route="deck-builder.html"]').textContent, "Montar um Cyberdeck");
    assert.ok(document.querySelector(".global-nav-cluster--netrunning.is-current"));
    assert.equal(document.querySelector(".global-nav-cart-link").getAttribute("aria-label"), "Carrinho, 0 itens");
  });
});
