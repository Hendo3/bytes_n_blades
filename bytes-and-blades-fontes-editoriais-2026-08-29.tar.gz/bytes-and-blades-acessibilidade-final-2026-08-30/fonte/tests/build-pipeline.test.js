const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { afterEach, describe, test } = require("node:test");

const root = path.resolve(__dirname, "..");
const tempRoot = path.join(root, "tmp", "test-runtime");
const temporaryDirectories = [];

function makeTemp(prefix) {
  fs.mkdirSync(tempRoot, { recursive: true });
  const directory = fs.mkdtempSync(path.join(tempRoot, prefix));
  temporaryDirectories.push(directory);
  return directory;
}

function run(command, args, options = {}) {
  return spawnSync(command, args, {
    cwd: options.cwd || root,
    encoding: "utf8",
    env: { ...process.env, TMPDIR: tempRoot },
  });
}

function listFiles(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolute = path.join(directory, entry.name);
    return entry.isDirectory()
      ? listFiles(absolute)
      : [path.relative(directory, absolute).replace(/\\/g, "/")];
  });
}

function listFilesFrom(base, directory = base) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolute = path.join(directory, entry.name);
    return entry.isDirectory()
      ? listFilesFrom(base, absolute)
      : [path.relative(base, absolute).replace(/\\/g, "/")];
  });
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function assertCanonicalBytes(sandbox, targets, label) {
  for (const target of targets) {
    assert.deepEqual(
      fs.readFileSync(path.join(sandbox, target)),
      fs.readFileSync(path.join(root, target)),
      `${label} changed canonical bytes in ${target}`,
    );
  }
}

function runGeneratorTwice(sandbox, command, args, targets, label) {
  for (let pass = 1; pass <= 2; pass += 1) {
    const result = run(command, args, { cwd: sandbox });
    assert.equal(result.status, 0, `${label} pass ${pass}: ${result.stderr || result.stdout}`);
    assertCanonicalBytes(sandbox, targets, `${label} pass ${pass}`);
  }
}

afterEach(() => {
  while (temporaryDirectories.length) {
    fs.rmSync(temporaryDirectories.pop(), { recursive: true, force: true });
  }
});

describe("static build and artifact validation", () => {
  test("build copies every publishable source byte-for-byte and nothing else", () => {
    const result = run(process.execPath, ["scripts/build-static.js"]);
    assert.equal(result.status, 0, result.stderr || result.stdout);
    const dist = path.join(root, "dist");

    const expected = [];
    for (const directory of ["assets", "css", "data", "html", "js"]) {
      expected.push(...listFilesFrom(root, path.join(root, directory)));
    }
    expected.push("index.html", "login.html", "manifest.webmanifest", "manifest.pt-BR.webmanifest", "service-worker.js");
    expected.sort();

    const actual = listFilesFrom(dist).sort();
    assert.deepEqual(actual, expected);
    for (const relative of expected) {
      assert.deepEqual(
        fs.readFileSync(path.join(dist, relative)),
        fs.readFileSync(path.join(root, relative)),
        relative,
      );
    }
  });

  test("validator accepts the real build and rejects broken JSON, links and artifacts", () => {
    let result = run(process.execPath, ["scripts/build-static.js"]);
    assert.equal(result.status, 0, result.stderr || result.stdout);
    result = run(process.execPath, ["scripts/validate-static.js", "dist"]);
    assert.equal(result.status, 0, result.stderr || result.stdout);
    assert.match(result.stdout, /validated \d+ static files/);

    const broken = makeTemp("broken-build-");
    fs.cpSync(path.join(root, "dist"), broken, { recursive: true });
    fs.writeFileSync(path.join(broken, "data", "broken.json"), "{");
    fs.appendFileSync(path.join(broken, "index.html"), "<script src='./js/missing.js'></script>");
    fs.rmSync(path.join(broken, "assets", "icons", "icon-192.png"));
    const invalid = run(process.execPath, [path.join(root, "scripts/validate-static.js"), broken]);
    assert.notEqual(invalid.status, 0);
    assert.match(invalid.stderr, /invalid JSON/);
    assert.match(invalid.stderr, /missing \.\/js\/missing\.js/);
    assert.match(invalid.stderr, /missing required artifact assets\/icons\/icon-192\.png/);
  });

  test("dataset validator covers every base and localized catalog", () => {
    const valid = run(process.execPath, ["js/validate_data.js"]);
    assert.equal(valid.status, 0, valid.stderr || valid.stdout);
    for (const label of [
      "cyberwares",
      "cyberwares.pt-BR",
      "equipment",
      "equipment.pt-BR",
      "weapons",
      "weapons.pt-BR",
      "drugs",
      "drugs.pt-BR",
      "chip-rates",
      "chip-rates.pt-BR",
    ]) {
      assert.match(valid.stdout, new RegExp(`Dataset "${label.replace(".", "\\.")}"`));
    }

    const invalidRoot = makeTemp("invalid-data-");
    fs.mkdirSync(path.join(invalidRoot, "js"));
    fs.cpSync(path.join(root, "js/validate_data.js"), path.join(invalidRoot, "js/validate_data.js"));
    fs.cpSync(path.join(root, "data"), path.join(invalidRoot, "data"), { recursive: true });
    const equipmentPath = path.join(invalidRoot, "data/equipment.json");
    const equipment = readJson(equipmentPath);
    delete equipment.data;
    fs.writeFileSync(equipmentPath, JSON.stringify(equipment));
    const invalid = run(process.execPath, [path.join(invalidRoot, "js/validate_data.js")], { cwd: invalidRoot });
    assert.notEqual(invalid.status, 0);
    assert.match(invalid.stderr, /Inconsistências em "equipment"/);
  });
});

describe("restoration and localization generators", () => {
  test("package scripts and README expose the documented localization and coverage contracts", () => {
    const packageJson = readJson(path.join(root, "package.json"));
    const readme = fs.readFileSync(path.join(root, "README.md"), "utf8");
    const localizers = [
      "localize:cyberware:pt-BR",
      "localize:equipment:pt-BR",
      "localize:weapons:pt-BR",
      "localize:ammo:pt-BR",
      "localize:drugs:pt-BR",
      "localize:chips:pt-BR",
      "localize:pt-BR",
    ];

    for (const name of localizers) {
      assert.equal(typeof packageJson.scripts[name], "string", name);
      assert.match(readme, new RegExp(`npm run ${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`));
    }
    assert.notEqual(packageJson.scripts.test, packageJson.scripts["test:quick"]);
    assert.doesNotMatch(packageJson.scripts["test:quick"], /test-coverage/);
    assert.match(packageJson.scripts.test, /--test-coverage-lines=99(?:\s|$)/);
    assert.match(packageJson.scripts.test, /--test-coverage-branches=80(?:\s|$)/);
    assert.match(packageJson.scripts.test, /--test-coverage-functions=95(?:\s|$)/);
    assert.match(readme, /99% das linhas/);
    assert.match(readme, /80% dos ramos/);
    assert.match(readme, /95% das funções/);
  });

  test("all catalog generators are deterministic and idempotent", () => {
    const sandbox = makeTemp("generators-");
    fs.cpSync(path.join(root, "data"), path.join(sandbox, "data"), { recursive: true });
    fs.cpSync(path.join(root, "scripts"), path.join(sandbox, "scripts"), { recursive: true });

    const commands = [
      ["scripts/repair-equipment-en.py", ["data/equipment.json"]],
      ["scripts/build-equipment-ptbr.py", ["data/equipment.pt-BR.json"]],
      ["scripts/repair-weapons-en.py", ["data/weapons.json"]],
      ["scripts/build-weapons-ptbr.py", ["data/weapons.pt-BR.json"]],
      ["scripts/repair-drugs-en.py", ["data/drugs.json"]],
      ["scripts/build-drugs-ptbr.py", ["data/drugs.pt-BR.json"]],
      ["scripts/build-chip-rates-ptbr.py", ["data/chip-rates.pt-BR.json"]],
      ["scripts/build-cyberwares-ptbr.py", ["data/cyberwares.pt-BR.json"]],
    ];

    for (const [script, targets] of commands) {
      runGeneratorTwice(sandbox, "python3", [script], targets, script);
    }

    runGeneratorTwice(sandbox, "python3", [
      "scripts/finalize_installation_data.py", "data/cyberwares.json",
      "data/cyberwares.schema.json", "data/equipment.json",
    ], ["data/cyberwares.json", "data/cyberwares.schema.json"], "finalize_installation_data.py");

    runGeneratorTwice(sandbox, process.execPath, ["scripts/build-ammo-data.js"], [
      "data/ammo.json", "data/ammo.pt-BR.json",
    ], "build-ammo-data.js");
    runGeneratorTwice(sandbox, process.execPath, ["scripts/build-netrunning-data.js"], [
      "data/programs.json", "data/programs.pt-BR.json",
      "data/cyberdecks.json", "data/cyberdecks.pt-BR.json",
    ], "build-netrunning-data.js");
  });
});
