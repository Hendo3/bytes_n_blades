const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { afterEach, describe, test } = require("node:test");
const Ajv = require("ajv");
const {
  installBrowserEnv,
  requireFresh,
  dispatchDOMContentLoaded,
  flushPromises,
  jsonResponse,
} = require("./helpers/browser-env.js");

const root = path.resolve(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const json = (file) => JSON.parse(read(file));
const cleanups = [];

function useBrowser(options) {
  const browser = installBrowserEnv(options);
  cleanups.push(browser.cleanup);
  return browser;
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  delete global.I18n;
  delete global.CyberSources;
});

function flatten(payload) {
  return Object.values(payload.data || {}).flatMap((category) => Object.entries(
    category.items || category.itens || category.list || {},
  ).map(([key, item]) => item.id || key));
}

describe("official editorial source registry", () => {
  const registry = json("data/editorial-sources.json");

  test("registry conforms to its schema", () => {
    const validate = new Ajv({ allErrors: true, strict: false })
      .compile(json("data/editorial-sources.schema.json"));
    assert.equal(validate(registry), true, JSON.stringify(validate.errors, null, 2));
  });

  test("every weapon, ammunition record and cyberware item has an explicit source state", () => {
    const expected = {
      weapons: json("data/weapons.json").weapons.map((item) => item.id),
      ammo: json("data/ammo.json").items.map((item) => item.id),
      cyberwares: flatten(json("data/cyberwares.json")),
    };
    for (const [catalog, ids] of Object.entries(expected)) {
      assert.deepEqual(Object.keys(registry.catalogs[catalog].items), ids, catalog);
    }
  });

  test("all 184 weapon citations resolve to verified official reprint pages", () => {
    const references = Object.values(registry.catalogs.weapons.items);
    assert.equal(references.length, 184);
    assert.ok(references.every((source) => (
      source.sourceId === "blackhands"
      && source.verification === "page"
      && /^\d+$/.test(source.pages)
    )));
  });

  test("source references are closed over the book registry and unresolved pages are honest", () => {
    for (const feed of Object.values(registry.catalogs)) {
      const references = [feed.default, ...Object.values(feed.categories || {}), ...Object.values(feed.items || {})]
        .filter(Boolean);
      for (const source of references) {
        assert.ok(registry.books[source.sourceId], source.sourceId);
        if (["page", "section"].includes(source.verification)) assert.ok(String(source.pages || "").trim());
        if (source.verification === "unverified") assert.equal(source.sourceId, "unverified");
      }
    }
  });

  test("unofficial compilation titles are inventory only, never public book citations", () => {
    const titles = Object.values(registry.books).map((book) => book.title).join("\n");
    assert.doesNotMatch(titles, /Weapons Listing v5|Ammunition & Add-ons/i);
    assert.ok(registry.method.inventory.every((entry) => /unofficial inventory only/i.test(entry)));
    assert.match(registry.method.citationPolicy, /never presented as editorial sources/i);
  });

  test("browser resolver expands a verified source and localizes unresolved labels", () => {
    delete require.cache[require.resolve("../js/editorial-sources.js")];
    global.I18n = { isPtBr: () => false };
    const sources = require("../js/editorial-sources.js");
    sources.state.data = registry;
    const firstWeapon = json("data/weapons.json").weapons[0];
    const resolved = sources.resolve("weapons", firstWeapon.id);
    assert.equal(resolved.book, "Blackhand's Street Weapons 2020");
    assert.match(sources.label(resolved), /p\. 10$/);
    assert.equal(sources.label(sources.resolve("chips", "missing")), "OFFICIAL ORIGIN UNVERIFIED");
    global.I18n = { isPtBr: () => true };
    assert.equal(sources.label(sources.resolve("chips", "missing")), "ORIGEM OFICIAL NÃO VERIFICADA");
    delete global.I18n;
  });

  test("loads once, expands every fallback and creates accessible source lines", async () => {
    const requests = [];
    const { document, window } = useBrowser({
      html: "<!doctype html><html><body><div id=chip-rate-groups></div></body></html>",
      fetchImpl: async (url, options) => {
        requests.push({ url, options });
        return jsonResponse(registry);
      },
    });
    window.I18n = { isPtBr: () => false };
    const sources = requireFresh("js/editorial-sources.js");

    assert.equal(sources.normalizeInline(""), null);
    assert.equal(sources.normalizeInline(7), null);
    assert.deepEqual(sources.normalizeInline("Brainware"), {
      book: "Brainware", pages: null, verification: "book", kind: "official",
    });
    const loaded = await sources.load();
    assert.deepEqual(loaded, registry);
    assert.equal(await sources.load(), loaded);
    assert.equal(requests.length, 1);
    assert.match(requests[0].url, /data\/editorial-sources\.json$/);
    assert.equal(requests[0].options.cache, "no-store");

    const inline = sources.resolve("weapons", "missing", { book: "Inline", page: 7 });
    assert.equal(inline.book, "Inline");
    assert.equal(inline.pages, "7");
    const defaultSource = sources.resolve("accessories", "missing");
    assert.equal(defaultSource.book, "Cyberpunk 2020 Core Rulebook");
    assert.equal(defaultSource.verification, "section");
    const line = sources.createLine(defaultSource, "editorial-source custom");
    assert.equal(line.className, "editorial-source custom");
    assert.equal(line.dataset.sourceVerification, "section");
    assert.match(line.textContent, /^SOURCE \/\/ Cyberpunk 2020 Core Rulebook/);
    assert.equal(sources.label({ book: "Brainware" }), "Brainware · PAGE UNVERIFIED");

    sources.resetForTests();
    assert.equal(sources.state.data, null);
    assert.equal(await sources.load(42), null);
    document.getElementById("chip-rate-groups").remove();
    sources.decorateChipRows();
  });

  test("fails closed and decorates dynamically rendered chip rows once", async () => {
    const { document, window } = useBrowser({
      html: "<!doctype html><html><body><ul id=chip-rate-groups><li><span><span><button data-skill-id=athletics data-page-type=aptr data-section=physical>ADD</button></span></span></li></ul></body></html>",
      fetchImpl: async () => jsonResponse(registry),
    });
    window.I18n = { isPtBr: () => true };
    const sources = requireFresh("js/editorial-sources.js");
    dispatchDOMContentLoaded(document);
    await flushPromises();
    sources.decorateChipRows();
    sources.decorateChipRows();
    const lines = document.querySelectorAll(".editorial-source");
    assert.equal(lines.length, 1);
    assert.match(lines[0].textContent, /^FONTE \/\/ ORIGEM OFICIAL NÃO VERIFICADA$/);

    sources.resetForTests();
    assert.equal(await sources.load(async () => jsonResponse({}, { ok: false, status: 503 })), null);
    assert.equal(sources.state.loading, null);
    assert.equal(await sources.load(async () => { throw new Error("offline"); }), null);
    assert.equal(sources.resolve("missing", "missing", { book: "Fallback" }).book, "Fallback");
    assert.equal(sources.resolve("missing", "missing", null), null);
  });

  test("cards, search, cart and offline shell consume the same registry", () => {
    assert.match(read("js/script.js"), /CyberSources\?\.createLine/);
    assert.match(read("js/global-search.js"), /global-search-source/);
    assert.match(read("js/cart.js"), /CyberSources\?\.label/);
    assert.match(read("service-worker.js"), /data\/editorial-sources\.json/);
    assert.match(read("service-worker.js"), /js\/editorial-sources\.js/);
    for (const file of ["index.html", "login.html", ...fs.readdirSync(path.join(root, "html")).filter((name) => name.endsWith(".html")).map((name) => `html/${name}`)]) {
      assert.match(read(file), /editorial-sources\.js/, file);
    }
  });
});
