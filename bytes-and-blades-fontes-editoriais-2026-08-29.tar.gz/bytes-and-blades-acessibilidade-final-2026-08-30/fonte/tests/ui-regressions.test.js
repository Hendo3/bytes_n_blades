const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { test } = require("node:test");

const root = path.resolve(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const sha256 = (file) => crypto.createHash("sha256")
  .update(fs.readFileSync(path.join(root, file)))
  .digest("hex");

test("uses the bundled Mokoto type system across body and interface layers", () => {
  const css = read("css/styles.css");
  const expectedFonts = {
    "assets/fonts/Mokoto Glitch.ttf": "4ce53a09cc98a14b6976f6dff177a8bba1948bc66540ef3653b99eb49f30caca",
    "assets/fonts/Mokoto Glitch Mark.ttf": "d0578bdae906b599a7b7dbb4c5ed3bcb5b47514d9a5cfd67e5ee29a5a9bec05f",
  };

  for (const [file, hash] of Object.entries(expectedFonts)) {
    assert.equal(sha256(file), hash, file);
  }
  assert.match(css, /@font-face\s*\{[^}]*font-family:\s*"Mokoto Glitch"[^}]*Mokoto Glitch\.ttf[^}]*font-display:\s*swap/s);
  assert.match(css, /@font-face\s*\{[^}]*font-family:\s*"Mokoto Glitch Mark"[^}]*Mokoto Glitch Mark\.ttf[^}]*font-display:\s*swap/s);
  assert.match(css, /--font-body:\s*"Mokoto Glitch"/);
  assert.match(css, /--font-interface:\s*"Mokoto Glitch Mark"/);
  assert.match(css, /body\s*\{[^}]*font-family:\s*var\(--font-body\)/s);
  assert.match(css, /:where\([^)]*h1[^)]*nav[^)]*button[^)]*select[^)]*\)\s*\{[^}]*font-family:\s*var\(--font-interface\)/s);
  assert.doesNotMatch(css, /font-family:\s*monospace/);
});

test("catalog UI exposes no manual dice controls", () => {
  const script = read("js/script.js");
  const i18n = read("js/i18n.js");

  assert.doesNotMatch(script, /DiceEngine\s*\.\s*createButton\s*\(/);
  assert.doesNotMatch(script, /btn-dice|dice-area|catalog\.roll/);
  assert.doesNotMatch(i18n, /"catalog\.roll"/);
  assert.match(script, /automatic HL calculation/);
});

test("JACK OUT is a fixed single-line navigation action", () => {
  const auth = read("js/auth.js");
  const css = read("css/styles.css");

  assert.match(auth, /logoutLi\.className = "nav-session-action"/);
  assert.match(auth, /logoutBtn\.className = "jack-out-link"/);
  assert.match(css, /\.nav-links \.nav-session-action\s*\{[^}]*flex:\s*0 0 auto/s);
  assert.match(css, /\.nav-links \.jack-out-link\s*\{[^}]*white-space:\s*nowrap/s);
  assert.match(css, /\.nav-links \.jack-out-link\s*\{[^}]*min-width:\s*max-content/s);
});

test("navigation never injects search or pushes selectors outside the viewport", () => {
  const search = read("js/global-search.js");
  const css = read("css/styles.css");

  assert.doesNotMatch(search, /global-search-trigger/);
  assert.doesNotMatch(search, /insertBefore\(trigger/);
  assert.match(css, /html\s*\{[^}]*overflow-x:\s*hidden/s);
  assert.match(css, /\.navbar nav\s*\{[^}]*flex-wrap:\s*wrap/s);
  assert.match(css, /\.language-selector\s*\{[^}]*flex:\s*0 0 auto/s);
  assert.match(css, /\.language-selector select\s*\{[^}]*max-width:\s*86px/s);
  assert.match(css, /:where\(select\)\s*\{[^}]*max-width:\s*100%/s);
});

test("cart presentation is fully controlled by the shared stylesheet", () => {
  const cart = fs.readFileSync(path.join(root, "js/cart.js"), "utf8");
  assert.doesNotMatch(cart, /style\s*=/i);
  assert.doesNotMatch(cart, /\.style\./);
  assert.doesNotMatch(cart, /font-family:\s*monospace/i);
  assert.match(cart, /class="cart-technical-info"/);
  assert.match(cart, /className = "cart-line-stepper"/);
});
