const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { afterEach, describe, test } = require("node:test");

const {
  installBrowserEnv,
  projectRoot,
  requireFresh,
  dispatchDOMContentLoaded,
  flushPromises,
} = require("./helpers/browser-env.js");

const cleanups = [];

function useBrowser(options = {}) {
  const browser = installBrowserEnv({
    url: "https://bytes.test/html/weapons.html",
    html: "<!doctype html><html><head></head><body></body></html>",
    ...options,
  });
  cleanups.push(browser.cleanup);
  return browser;
}

function serviceWorkerHarness() {
  const listeners = {};
  const stores = new Map();
  let network = async (request) => new Response(`network:${request.url || request}`);
  let skipped = 0;
  let claimed = 0;
  const absolute = (value) => new URL(value?.url || value, "https://bytes.test/").href;
  const keyFor = (value, ignoreSearch = false) => {
    const url = new URL(absolute(value));
    if (ignoreSearch) url.search = "";
    return url.href;
  };

  function cache(name) {
    if (!stores.has(name)) stores.set(name, new Map());
    const entries = stores.get(name);
    return {
      async addAll(urls) {
        urls.forEach((url) => entries.set(absolute(url), new Response(`precache:${url}`)));
      },
      async put(request, response) { entries.set(absolute(request), response); },
      async match(request, options = {}) {
        const wanted = keyFor(request, options.ignoreSearch);
        for (const [key, response] of entries) {
          if (keyFor(key, options.ignoreSearch) === wanted) return response.clone();
        }
        return undefined;
      },
      async keys() { return [...entries.keys()].map((url) => ({ url })); },
      async delete(request) { return entries.delete(absolute(request)); },
    };
  }

  const caches = {
    open: async (name) => cache(name),
    keys: async () => [...stores.keys()],
    delete: async (name) => stores.delete(name),
    async match(request, options = {}) {
      for (const name of stores.keys()) {
        const response = await cache(name).match(request, options);
        if (response) return response;
      }
      return undefined;
    },
  };
  const self = {
    location: { origin: "https://bytes.test", href: "https://bytes.test/service-worker.js" },
    clients: { claim: async () => { claimed += 1; } },
    skipWaiting: async () => { skipped += 1; },
    addEventListener(type, listener) { listeners[type] = listener; },
  };
  const context = vm.createContext({
    self,
    caches,
    Response,
    Request,
    URL,
    Promise,
    Error,
    setTimeout,
    clearTimeout,
    fetch: (...args) => network(...args),
  });
  vm.runInContext(fs.readFileSync(path.join(projectRoot, "service-worker.js"), "utf8"), context);
  return {
    self,
    caches,
    stores,
    listeners,
    api: self.__BYTE_BLADES_SW__,
    setNetwork(fn) { network = fn; },
    counts: () => ({ skipped, claimed }),
  };
}

function lifecycleEvent() {
  let promise;
  return {
    event: { waitUntil(value) { promise = value; } },
    wait: () => promise,
  };
}

function fetchEvent(request) {
  let response;
  const pending = [];
  return {
    event: {
      request,
      respondWith(value) { response = value; },
      waitUntil(value) { pending.push(value); },
    },
    response: () => response,
    settle: () => Promise.all(pending),
  };
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  delete global.CyberPWA;
});

describe("real offline application shell", () => {
  test("pre-caches every route, controller and all 18 localized datasets atomically", async () => {
    const harness = serviceWorkerHarness();
    const { api } = harness;
    assert.equal(new Set(api.PRECACHE_URLS).size, api.PRECACHE_URLS.length);
    assert.equal(api.PRECACHE_URLS.filter((url) => /^\.\/data\/(?:cyberwares|equipment|decks|programs|cyberdecks|weapons|ammo|drugs|chip-rates)(?:\.pt-BR)?\.json$/.test(url)).length, 18);
    for (const required of [
      "./index.html",
      "./login.html",
      "./html/404.html",
      "./html/cart.html",
      "./js/i18n.js",
      "./js/global-navigation.js",
      "./js/pwa.js",
      "./css/styles.css",
      "./assets/fonts/Mokoto Glitch.ttf",
    ]) assert.ok(api.PRECACHE_URLS.includes(required), required);
    for (const url of api.PRECACHE_URLS.filter((entry) => entry !== "./")) {
      assert.ok(fs.existsSync(path.join(projectRoot, url.slice(2))), `missing precache source ${url}`);
    }

    const install = lifecycleEvent();
    harness.listeners.install(install.event);
    await install.wait();
    assert.equal(harness.counts().skipped, 1);
    assert.equal(harness.stores.get(api.PRECACHE).size, api.PRECACHE_URLS.length);

    harness.stores.set(`${api.CACHE_PREFIX}-precache-old`, new Map());
    harness.stores.set("unrelated-cache", new Map());
    const activate = lifecycleEvent();
    harness.listeners.activate(activate.event);
    await activate.wait();
    assert.equal(harness.stores.has(`${api.CACHE_PREFIX}-precache-old`), false);
    assert.equal(harness.stores.has("unrelated-cache"), true);
    assert.equal(harness.counts().claimed, 1);
  });

  test("serves cached navigation and assets when the network disappears", async () => {
    const harness = serviceWorkerHarness();
    const install = lifecycleEvent();
    harness.listeners.install(install.event);
    await install.wait();
    harness.setNetwork(async () => { throw new Error("offline"); });

    const navigation = fetchEvent({
      method: "GET",
      mode: "navigate",
      url: "https://bytes.test/html/weapons.html?item=gun",
    });
    harness.listeners.fetch(navigation.event);
    const navigationResponse = await navigation.response();
    assert.match(await navigationResponse.text(), /precache:\.\/html\/weapons\.html/);

    const unknown = fetchEvent({ method: "GET", mode: "navigate", url: "https://bytes.test/missing-route" });
    harness.listeners.fetch(unknown.event);
    assert.match(await (await unknown.response()).text(), /precache:\.\/html\/404\.html/);

    const asset = fetchEvent({ method: "GET", mode: "cors", url: "https://bytes.test/data/ammo.pt-BR.json?rev=2" });
    harness.listeners.fetch(asset.event);
    assert.match(await (await asset.response()).text(), /precache:\.\/data\/ammo\.pt-BR\.json/);
    await asset.settle();
  });

  test("refreshes cached assets, limits runtime growth and ignores unsafe requests", async () => {
    const harness = serviceWorkerHarness();
    const install = lifecycleEvent();
    harness.listeners.install(install.event);
    await install.wait();
    harness.setNetwork(async () => new Response("fresh"));

    const asset = fetchEvent({ method: "GET", mode: "cors", url: "https://bytes.test/css/styles.css" });
    harness.listeners.fetch(asset.event);
    assert.match(await (await asset.response()).text(), /precache/);
    await asset.settle();
    assert.equal(harness.stores.get(harness.api.RUNTIME).size, 1);

    const runtime = await harness.caches.open(harness.api.RUNTIME);
    for (let index = 0; index < 85; index += 1) {
      await runtime.put(`https://bytes.test/runtime/${index}`, new Response(String(index)));
    }
    await harness.api.trim(runtime);
    assert.equal((await runtime.keys()).length, 80);
    assert.equal(harness.api.cacheable(new Response("no", { status: 503 })), false);

    const post = fetchEvent({ method: "POST", mode: "cors", url: "https://bytes.test/order" });
    assert.equal(harness.listeners.fetch(post.event), undefined);
    assert.equal(post.response(), undefined);
    const external = fetchEvent({ method: "GET", mode: "cors", url: "https://corp.test/tracker" });
    harness.listeners.fetch(external.event);
    assert.equal(external.response(), undefined);

    const skip = lifecycleEvent();
    harness.listeners.message({ data: { type: "SKIP_WAITING" }, waitUntil: skip.event.waitUntil });
    assert.equal(harness.counts().skipped, 2);
    const clear = lifecycleEvent();
    harness.listeners.message({ data: { type: "CLEAR_RUNTIME" }, waitUntil: clear.event.waitUntil });
    await clear.wait();
    assert.equal(harness.stores.has(harness.api.RUNTIME), false);
  });
});

describe("PWA registration", () => {
  test("registers one root-scoped worker and reports network state", async () => {
    const { document, window } = useBrowser();
    Object.defineProperty(document, "currentScript", {
      configurable: true,
      value: { src: "https://bytes.test/js/pwa.js" },
    });
    const serviceListeners = {};
    const registrationListeners = {};
    const calls = [];
    const worker = {
      controller: null,
      addEventListener(type, listener) { serviceListeners[type] = listener; },
      async register(url, options) {
        calls.push({ url, options });
        return { addEventListener(type, listener) { registrationListeners[type] = listener; } };
      },
    };
    Object.defineProperty(window.navigator, "serviceWorker", { configurable: true, value: worker });
    Object.defineProperty(window.navigator, "onLine", { configurable: true, writable: true, value: true });
    const states = [];
    window.addEventListener("pwa-state", (event) => states.push(event.detail.state));
    const pwa = requireFresh("js/pwa.js");
    dispatchDOMContentLoaded(document);
    await flushPromises();

    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, "https://bytes.test/service-worker.js");
    assert.equal(calls[0].options.scope, "https://bytes.test/");
    assert.equal(calls[0].options.updateViaCache, "none");
    assert.equal(document.documentElement.dataset.pwaState, "ready");
    assert.equal(await pwa.register(), await pwa.register());
    assert.equal(calls.length, 1);

    registrationListeners.updatefound();
    assert.equal(document.documentElement.dataset.pwaState, "updating");
    window.navigator.onLine = false;
    window.dispatchEvent(new window.Event("offline"));
    assert.equal(document.documentElement.dataset.pwaState, "offline");
    worker.controller = {};
    window.navigator.onLine = true;
    window.dispatchEvent(new window.Event("online"));
    assert.equal(document.documentElement.dataset.pwaState, "cached");
    serviceListeners.controllerchange();
    assert.equal(states.at(-1), "cached");
  });

  test("degrades cleanly when registration is unsupported or rejected", async () => {
    let browser = useBrowser({ url: "file:///tmp/index.html" });
    let pwa = requireFresh("js/pwa.js");
    dispatchDOMContentLoaded(browser.document);
    await flushPromises();
    assert.equal(pwa.available(), false);
    assert.equal(browser.document.documentElement.dataset.pwaState, "unsupported");

    browser.cleanup();
    cleanups.pop();
    browser = useBrowser();
    Object.defineProperty(browser.document, "currentScript", {
      configurable: true,
      value: { src: "https://bytes.test/js/pwa.js" },
    });
    Object.defineProperty(browser.window.navigator, "serviceWorker", {
      configurable: true,
      value: {
        addEventListener() {},
        register: async () => { throw new Error("blocked"); },
      },
    });
    pwa = requireFresh("js/pwa.js");
    dispatchDOMContentLoaded(browser.document);
    await flushPromises();
    assert.equal(browser.document.documentElement.dataset.pwaState, "unavailable");
    assert.equal(await pwa.register(), null);
  });
});
