const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { afterEach, describe, test } = require("node:test");

const {
  projectRoot,
  installBrowserEnv,
  requireFresh,
} = require("./helpers/browser-env.js");

const cleanups = [];

function useBrowser(options) {
  const browser = installBrowserEnv(options);
  cleanups.push(browser.cleanup);
  return browser;
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  for (const key of ["CyberDialogs", "Modal", "HackSystem"]) delete global[key];
});

describe("accessible dialog contract", () => {
  test("contains keyboard and programmatic focus, handles Escape and restores the opener", () => {
    const { document, window } = useBrowser({
      html: `<!doctype html><html><body>
        <button id="trigger">OPEN</button><button id="outside">OUTSIDE</button>
        <div id="shell"><section id="dialog" aria-labelledby="title"><h2 id="title">Dialog</h2>
          <button id="first">FIRST</button><button id="last">LAST</button>
        </section></div>
      </body></html>`,
    });
    const dialogs = requireFresh("js/dialog-a11y.js");
    const trigger = document.getElementById("trigger");
    const shell = document.getElementById("shell");
    const dialog = document.getElementById("dialog");
    const first = document.getElementById("first");
    const last = document.getElementById("last");
    trigger.focus();
    let escaped = 0;
    dialogs.activate(shell, {
      dialog,
      initialFocus: first,
      onEscape: () => {
        escaped += 1;
        dialogs.deactivate(shell);
      },
    });

    assert.equal(dialog.getAttribute("role"), "dialog");
    assert.equal(dialog.getAttribute("aria-modal"), "true");
    assert.equal(dialogs.isActive(shell), true);
    assert.equal(document.body.classList.contains("dialog-open"), true);
    assert.equal(document.activeElement, first);

    first.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", shiftKey: true, bubbles: true }));
    assert.equal(document.activeElement, last);
    last.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", bubbles: true }));
    assert.equal(document.activeElement, first);
    document.getElementById("outside").focus();
    assert.equal(document.activeElement, first);

    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.equal(escaped, 1);
    assert.equal(dialogs.isActive(shell), false);
    assert.equal(document.body.classList.contains("dialog-open"), false);
    assert.equal(document.activeElement, trigger);
  });

  test("uses the dialog itself when no focusable control exists and supports stacked dialogs", () => {
    const { document, window } = useBrowser({
      html: "<!doctype html><html><body><button id=origin>ORIGIN</button><div id=one><section></section></div><div id=two><section><button>OK</button></section></div></body></html>",
    });
    const dialogs = requireFresh("js/dialog-a11y.js");
    const origin = document.getElementById("origin");
    const one = document.getElementById("one");
    const oneDialog = one.querySelector("section");
    const two = document.getElementById("two");
    origin.focus();
    dialogs.activate(one, { dialog: oneDialog, onEscape: false });
    assert.equal(document.activeElement, oneDialog);
    one.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", bubbles: true }));
    assert.equal(document.activeElement, oneDialog);

    dialogs.activate(two, { dialog: two.querySelector("section"), returnFocus: oneDialog, onEscape: false });
    assert.equal(document.activeElement, two.querySelector("button"));
    assert.equal(dialogs.deactivate(two), true);
    assert.equal(document.activeElement, oneDialog);
    assert.equal(document.body.classList.contains("dialog-open"), true);
    assert.equal(dialogs.deactivate(one, { restoreFocus: false }), true);
    assert.equal(dialogs.deactivate(one), false);
    assert.equal(document.body.classList.contains("dialog-open"), false);
    assert.equal(dialogs.focus(null), false);
    assert.deepEqual(dialogs.focusable(null), []);
    let fallbackFocus = 0;
    assert.equal(dialogs.focus({
      focus(options) {
        if (options) throw new Error("legacy focus signature");
        fallbackFocus += 1;
      },
    }), true);
    assert.equal(fallbackFocus, 1);
  });

  test("custom alert and confirm expose names, cancel with Escape and return focus", () => {
    const { document, window } = useBrowser({
      html: "<!doctype html><html><body><button id=origin>OPEN</button><button id=outside>OUTSIDE</button></body></html>",
    });
    requireFresh("js/dialog-a11y.js");
    const modal = requireFresh("js/modal.js");
    const events = [];
    const origin = document.getElementById("origin");
    origin.focus();
    modal.confirm("DELETE?", "Cannot be undone", () => events.push("confirm"), () => events.push("cancel"));

    const overlay = document.getElementById("custom-modal");
    const dialog = overlay.querySelector(".modal-box");
    assert.equal(dialog.getAttribute("aria-labelledby"), "custom-modal-title");
    assert.equal(dialog.getAttribute("aria-describedby"), "custom-modal-description");
    assert.equal(document.getElementById(dialog.getAttribute("aria-labelledby")).textContent, "DELETE?");
    assert.equal(document.getElementById(dialog.getAttribute("aria-describedby")).textContent, "Cannot be undone");
    assert.equal(document.activeElement, overlay.querySelector(".btn-danger"));
    document.getElementById("outside").focus();
    assert.equal(document.activeElement, overlay.querySelector(".btn-danger"));
    overlay.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.deepEqual(events, ["cancel"]);
    assert.equal(document.getElementById("custom-modal"), null);
    assert.equal(document.activeElement, origin);

    modal.alert("SYSTEM", "Ready", () => events.push("ack"));
    document.getElementById("custom-modal").dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.deepEqual(events, ["cancel", "ack"]);
    assert.equal(document.activeElement, origin);
    assert.equal(modal.close(), false);
  });

  test("breach overlay is a named dialog and Escape closes it as a failed attempt", () => {
    const { document, window } = useBrowser({
      html: "<!doctype html><html><body><button id=origin>BREACH</button><button id=outside>OUTSIDE</button></body></html>",
    });
    requireFresh("js/dialog-a11y.js");
    const hack = requireFresh("js/hack.js");
    const results = [];
    const origin = document.getElementById("origin");
    origin.focus();
    hack.onComplete = (result) => results.push(result);
    hack.createUI();
    const overlay = document.getElementById("hack-overlay");
    const dialog = overlay.querySelector(".hack-terminal");
    assert.equal(dialog.getAttribute("role"), "dialog");
    assert.equal(dialog.getAttribute("aria-modal"), "true");
    assert.equal(dialog.getAttribute("aria-labelledby"), "hack-title");
    assert.equal(dialog.getAttribute("aria-describedby"), "hack-msg");
    assert.equal(document.activeElement.id, "btn-hack-stop");
    document.getElementById("outside").focus();
    assert.equal(document.activeElement.id, "btn-hack-stop");
    overlay.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.deepEqual(results, [false]);
    assert.equal(document.getElementById("hack-overlay"), null);
    assert.equal(document.activeElement, origin);
    assert.equal(hack.close(false), false);
  });

  test("modal and breach keep functional focus fallbacks without the shared controller", () => {
    const { document, window } = useBrowser({
      html: "<!doctype html><html><body><button id=origin>OPEN</button></body></html>",
    });
    const origin = document.getElementById("origin");
    origin.focus();
    const modal = requireFresh("js/modal.js");
    modal.alert("LEGACY", "Fallback");
    assert.equal(document.activeElement, document.querySelector("#custom-modal button"));
    document.querySelector("#custom-modal button").click();
    assert.equal(document.activeElement, origin);

    const results = [];
    const hack = requireFresh("js/hack.js");
    hack.onComplete = (result) => results.push(result);
    hack.createUI();
    const overlay = document.getElementById("hack-overlay");
    assert.equal(document.activeElement.id, "btn-hack-stop");
    overlay.dispatchEvent(new window.KeyboardEvent("keydown", { key: "X", bubbles: true }));
    assert.ok(document.getElementById("hack-overlay"));
    overlay.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.deepEqual(results, [false]);
    assert.equal(document.activeElement, origin);
  });

  test("every route loads the focus controller before localization and it is available offline", () => {
    const files = [
      "index.html",
      "login.html",
      ...fs.readdirSync(path.join(projectRoot, "html"))
        .filter((name) => name.endsWith(".html"))
        .map((name) => `html/${name}`),
    ];
    for (const file of files) {
      const html = fs.readFileSync(path.join(projectRoot, file), "utf8");
      const dialogs = html.indexOf("dialog-a11y.js");
      const i18n = html.indexOf("i18n.js");
      assert.ok(dialogs >= 0 && dialogs < i18n, file);
    }
    assert.match(fs.readFileSync(path.join(projectRoot, "service-worker.js"), "utf8"), /\.\/js\/dialog-a11y\.js/);
  });
});
