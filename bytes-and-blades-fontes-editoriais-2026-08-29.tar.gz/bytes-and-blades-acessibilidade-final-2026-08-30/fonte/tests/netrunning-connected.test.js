const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { afterEach, describe, test } = require("node:test");
const { JSDOM } = require("jsdom");

const {
  projectRoot,
  installBrowserEnv,
  requireFresh,
  dispatchDOMContentLoaded,
  jsonResponse,
  flushPromises,
} = require("./helpers/browser-env.js");

const cleanups = [];
const readText = (relativePath) => fs.readFileSync(path.join(projectRoot, relativePath), "utf8");
const readJson = (relativePath) => JSON.parse(readText(relativePath));
const sha256 = (relativePath) => crypto.createHash("sha256")
  .update(fs.readFileSync(path.join(projectRoot, relativePath)))
  .digest("hex");

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  delete global.CyberUtils;
});

describe("protected prebuilt areas", () => {
  test("keeps the Cyberware catalogs and installation engine byte-for-byte", () => {
    const expected = {
      "js/core-utils.js": "c3573ac2e3f2c20b2e606fc20b317523c4fcb20bcf84854dacf454e20f971c08",
      "js/chip-rates.js": "7c4195b51c76be3be76f34e6b3b9e5bc24253d72647930539801db4ea0a51b44",
      "data/cyberwares.json": "d8c961b7c0e479a07096c70b3d4a9b3e5949fd381cdd82094c3455a078bc2776",
      "data/cyberwares.pt-BR.json": "0461c4dc89a715b90d014f004abed3d51071076e4209b36320f2faf3eeceda83",
      "data/equipment.json": "89b2c8d296b1200ab136fae8ef013793f7bc014cbfa23c10486d2ea51f177577",
      "data/equipment.pt-BR.json": "8dc9574b8869e557bd8657fc9ee128ec73c1691c37c50d8d0fbb5476f83ef196",
    };
    for (const [relativePath, hash] of Object.entries(expected)) {
      assert.equal(sha256(relativePath), hash, relativePath);
    }
  });
});

describe("global cyberpunk controls", () => {
  test("loads the shared control system on every page through i18n", () => {
    assert.match(readText("js/i18n.js"), /ui-controls\.js/);
    assert.match(readText("css/styles.css"), /GLOBAL CYBER CONTROL SYSTEM/);
    assert.ok(fs.existsSync(path.join(projectRoot, "js/ui-controls.js")));
  });

  test("turns number fields into accessible steppers without changing their identity", async () => {
    const browser = installBrowserEnv({
      html: '<label for="price">Max price</label><input id="price" name="price" type="number" min="0" max="20" step="10" value="0">',
    });
    cleanups.push(browser.cleanup);
    const controls = requireFresh("js/ui-controls.js");
    controls.boot(document);
    const input = document.getElementById("price");
    const wrapper = input.closest(".cyber-stepper");
    assert.ok(wrapper);
    assert.equal(input.id, "price");
    wrapper.querySelector(".cyber-stepper__button--up").click();
    assert.equal(input.value, "10");
    wrapper.querySelector(".cyber-stepper__button--down").click();
    assert.equal(input.value, "0");
    assert.match(wrapper.querySelector(".cyber-stepper__button--up").getAttribute("aria-label"), /Max price/);
    input.disabled = true;
    controls.stepNumber(input, 1);
    assert.equal(input.value, "0");
    input.disabled = false;
    input.readOnly = true;
    controls.stepNumber(input, 1);
    assert.equal(input.value, "0");
    controls.enhance(null);
    controls.enhanceNumberInput(input);
    assert.equal(document.querySelectorAll(".cyber-stepper").length, 1);

    const dynamic = document.createElement("input");
    dynamic.type = "number";
    dynamic.name = "quantity";
    document.body.appendChild(dynamic);
    await flushPromises(2);
    assert.ok(dynamic.closest(".cyber-stepper"));
  });

  test("boots immediately when the document has already loaded", () => {
    const browser = installBrowserEnv({ html: '<input id="ready-price" type="number" value="1">' });
    cleanups.push(browser.cleanup);
    Object.defineProperty(document, "readyState", { configurable: true, value: "complete" });
    requireFresh("js/ui-controls.js");
    assert.equal(document.documentElement.dataset.cyberControls, "ready");
    assert.ok(document.getElementById("ready-price").closest(".cyber-stepper"));
  });
});

describe("Brainware catalogs", () => {
  test("ships the complete bilingual program and cyberdeck catalogs", () => {
    for (const suffix of ["", ".pt-BR"]) {
      const programs = readJson(`data/programs${suffix}.json`);
      const cyberdecks = readJson(`data/cyberdecks${suffix}.json`);
      assert.equal(programs.programs.length, 267);
      assert.equal(programs.programs.filter((item) => item.catalog_scope === "standard").length, 160);
      assert.equal(programs.programs.filter((item) => item.catalog_scope === "netrunner_conversion").length, 107);
      assert.equal(new Set(programs.programs.map((item) => item.id)).size, 267);
      assert.equal(cyberdecks.decks.length, 32);
      assert.equal(cyberdecks.decks.filter((item) => item.catalog_scope === "standard").length, 27);
      assert.equal(cyberdecks.decks.filter((item) => item.catalog_scope === "netrunner_conversion").length, 5);
      assert.equal(new Set(cyberdecks.decks.map((item) => item.id)).size, 32);
      assert.equal(cyberdecks.builder.chassis.length, 7);
      assert.equal(cyberdecks.builder.options.length, 21);
    }
  });

  test("attributes Brainware and Guide decks without duplicating reprints", () => {
    const decks = readJson("data/cyberdecks.json").decks;
    assert.equal(decks.filter((deck) => deck.source.book === "Rache Bartmoss' Brainware Blowout").length, 26);
    const guideIds = [
      "langley_datastick_mark_vii",
      "liz_cyber_spandeck",
      "microtech_cad_4_commando",
    ];
    for (const id of guideIds) {
      const deck = decks.find((item) => item.id === id);
      assert.ok(deck, id);
      assert.equal(deck.source.book, "Rache Bartmoss' Guide to the Net");
      assert.equal(deck.reprint_source.book, "Rache Bartmoss' Brainware Blowout");
    }
    assert.equal(decks.find((deck) => deck.id === "microtech_cad_4_commando").armor_sp, 20);
  });
});

describe("connected Netrunning experience", () => {
  test("links Programs, Cyberdecks and Build a Deck in every Netrunning route", () => {
    const contracts = {
      "html/programs.html": ["program-search", "program-class", "program-conversions", "program-list"],
      "html/cyberdecks.html": ["deck-conversions", "deck-list", "netgear-list"],
      "html/deck-builder.html": ["deck-builder-form", "deck-options", "builder-programs", "builder-add"],
    };
    for (const [relativePath, ids] of Object.entries(contracts)) {
      const dom = new JSDOM(readText(relativePath));
      ids.forEach((id) => assert.ok(dom.window.document.getElementById(id), `${relativePath}: #${id}`));
      const links = [...dom.window.document.querySelectorAll(".net-tabs a")].map((link) => link.getAttribute("href"));
      assert.deepEqual(links, ["./programs.html", "./cyberdecks.html", "./deck-builder.html"]);
      assert.ok(dom.window.document.querySelector('script[src="../js/netrunning.js"]'));
      dom.window.close();
    }
    const home = readText("index.html");
    assert.match(home, /href="\.\/html\/cyberdecks\.html" class="market-node"/);
    assert.match(home, /href="\.\/html\/deck-builder\.html" class="btn-secondary">Build a Deck/);
  });

  test("loads only deck-compatible software and enforces MU", () => {
    const browser = installBrowserEnv();
    cleanups.push(browser.cleanup);
    const utils = requireFresh("js/core-utils.js");
    window.CyberUtils = utils;
    global.CyberUtils = utils;
    const net = requireFresh("js/netrunning.js");
    const programs = readJson("data/programs.json").programs;
    const builder = readJson("data/cyberdecks.json").builder;
    const result = net.calculateDeck(builder, programs, {
      chassisId: "standard",
      expandedMemory: true,
      speed: 3,
      dataWall: 4,
      connectionId: "interface_plugs",
      programIds: ["hammer", "trailer_hitch", "systemware_cloak"],
    });
    assert.deepEqual(result.programs.map((program) => program.id), ["hammer", "trailer_hitch"]);
    assert.equal(result.memory, 24);
    assert.equal(result.speed, 2);
    assert.ok(result.memoryUsed <= result.memory);
    assert.equal(result.valid, true);
  });

  test("renders both shelves and stores programs, published decks and complete builds in the cart", async () => {
    const programs = readJson("data/programs.json");
    const cyberdecks = readJson("data/cyberdecks.json");
    const markup = `<!doctype html><body data-netrunning-page="all">
      <p id="net-status"></p><div class="net-filters"><input id="program-search"><select id="program-class"><option value=""></option></select><input id="program-price"><input id="program-conversions" type="checkbox"></div><span id="program-count"></span><div id="program-list"></div>
      <label><input id="deck-conversions" type="checkbox"></label><span id="deck-count"></span><div id="deck-list"></div><div id="netgear-list"></div>
      <input id="builder-conversions" type="checkbox"><form id="deck-builder-form"><select name="chassis"></select><label><input name="usedStandard" type="checkbox"></label><label><input name="expandedMemory" type="checkbox"></label><select name="speed"></select><select name="dataWall"></select><select name="connection"></select><div id="deck-options"></div><div id="builder-programs"></div></form>
      <span id="builder-total"></span><span id="builder-capacity"></span><span id="builder-breakdown"></span><button id="builder-add"></button>
    </body>`;
    const browser = installBrowserEnv({
      html: markup,
      immediateTimers: true,
      fetchImpl: async (url) => jsonResponse(String(url).includes("programs") ? programs : cyberdecks),
    });
    cleanups.push(browser.cleanup);
    const utils = requireFresh("js/core-utils.js");
    window.CyberUtils = utils;
    global.CyberUtils = utils;
    window.I18n = { getLocale: () => "en-US", dataPath: (value) => value, t: (_key, _params, fallback) => fallback };
    requireFresh("js/permalinks.js");
    const comparisons = [];
    window.CyberComparator = { toggle: (candidate) => comparisons.push(candidate), syncButton() {} };
    requireFresh("js/netrunning.js");
    dispatchDOMContentLoaded(document);
    await flushPromises(8);

    assert.equal(document.querySelectorAll(".program-card").length, 160);
    assert.equal(document.querySelectorAll("#deck-list .deck-card").length, 27);
    assert.equal(document.querySelectorAll(".program-card .btn-compare").length, 160);
    assert.equal(document.querySelectorAll("#deck-list .btn-compare").length, 27);
    assert.equal(document.querySelectorAll(".program-card .btn-share-link").length, 160);
    assert.equal(document.querySelectorAll("#deck-list .btn-share-link").length, 27);
    assert.ok(document.querySelector("[data-share-program-filter]"));
    assert.equal(document.querySelectorAll("#netgear-list .deck-card").length, 4);
    assert.equal(document.querySelectorAll(".builder-program").length, 146);
    assert.equal(document.querySelectorAll(".quantity-stepper").length, 4);
    assert.ok(document.querySelector('.builder-option input[type="checkbox"]'));

    const firstStepper = document.querySelector(".quantity-stepper");
    firstStepper.querySelector('[data-step="1"]').click();
    assert.equal(firstStepper.querySelector('input[type="number"]').value, "1");
    firstStepper.querySelector('[data-step="-1"]').click();
    assert.equal(firstStepper.querySelector('input[type="number"]').value, "0");

    document.getElementById("program-conversions").checked = true;
    document.getElementById("program-conversions").dispatchEvent(new window.Event("input"));
    document.getElementById("deck-conversions").checked = true;
    document.getElementById("deck-conversions").dispatchEvent(new window.Event("input"));
    assert.equal(document.querySelectorAll(".program-card").length, 267);
    assert.equal(document.querySelectorAll("#deck-list .deck-card").length, 32);

    document.getElementById("program-search").value = "Wizard's Book";
    document.getElementById("program-search").dispatchEvent(new window.Event("input"));
    assert.match(window.location.search, /q=Wizard%27s\+Book/);
    document.querySelector(".program-card .btn-add").click();
    document.querySelector("#deck-list .deck-card .btn-add").click();
    document.querySelector(".program-card .btn-compare").click();
    document.querySelector("#deck-list .deck-card .btn-compare").click();
    assert.deepEqual(comparisons.map((entry) => entry.catalog), ["programs", "cyberdecks"]);
    assert.ok(comparisons[0].stats.some((stat) => stat.key === "strength"));
    assert.ok(comparisons[1].stats.some((stat) => stat.key === "data_wall"));
    assert.equal(JSON.parse(localStorage.getItem("cyber_cart")).length, 2);

    localStorage.removeItem("cyber_cart");
    const form = document.getElementById("deck-builder-form");
    form.elements.chassis.value = "standard";
    form.elements.expandedMemory.checked = true;
    form.elements.speed.value = "2";
    form.elements.dataWall.value = "4";
    form.elements.connection.value = "keyboard";
    form.querySelector('[data-program="hammer"]').checked = true;
    form.dispatchEvent(new window.Event("input", { bubbles: true }));
    document.getElementById("builder-add").click();
    const cart = JSON.parse(localStorage.getItem("cyber_cart"));
    assert.equal(cart.length, 1);
    assert.equal(cart[0].deckConfiguration.kind, "custom");
    assert.deepEqual(cart[0].deckConfiguration.programIds, ["hammer"]);
    assert.ok(document.querySelector("#builder-add + .btn-share-link"));
  });

  test("restores every cyberdeck builder control from a permanent build URL", async () => {
    const programs = readJson("data/programs.json");
    const cyberdecks = readJson("data/cyberdecks.json");
    const browser = installBrowserEnv({
      url: "https://bytes.test/html/deck-builder.html?build=1&chassis=portable&memory=1&speed=3&wall=5&connection=trodes&option=printer%3A1&option=scanner%3Aprofessional&option=video_monitor%3A2&program=hammer",
      html: `<!doctype html><body><input id="builder-conversions" type="checkbox"><form id="deck-builder-form">
        <select name="chassis"></select><label><input name="usedStandard" type="checkbox"></label><label><input name="expandedMemory" type="checkbox"></label>
        <select name="speed"></select><select name="dataWall"></select><select name="connection"></select><div id="deck-options"></div><div id="builder-programs"></div>
        <span id="builder-total"></span><span id="builder-capacity"></span><span id="builder-breakdown"></span><button id="builder-add" type="button"></button>
      </form></body>`,
    });
    cleanups.push(browser.cleanup);
    window.I18n = { getLocale: () => "en-US", t: (_key, _params, fallback) => fallback };
    const copied = [];
    Object.defineProperty(window.navigator, "clipboard", {
      configurable: true,
      value: { writeText: async (value) => copied.push(value) },
    });
    requireFresh("js/permalinks.js");
    const net = requireFresh("js/netrunning.js");
    net.initBuilder(programs, cyberdecks);

    const form = document.getElementById("deck-builder-form");
    assert.equal(form.elements.chassis.value, "portable");
    assert.equal(form.elements.expandedMemory.checked, true);
    assert.equal(form.elements.speed.value, "3");
    assert.equal(form.elements.dataWall.value, "5");
    assert.equal(form.elements.connection.value, "trodes");
    assert.equal(form.querySelector('[data-option="printer"]').checked, true);
    assert.equal(form.querySelector('[data-option="scanner"]').value, "professional");
    assert.equal(form.querySelector('[data-option="video_monitor"]').value, "2");
    assert.equal(form.querySelector('[data-program="hammer"]').checked, true);

    document.querySelector("#builder-add + .btn-share-link").click();
    await flushPromises();
    const shared = new URL(copied[0]);
    assert.equal(shared.searchParams.get("chassis"), "portable");
    assert.equal(shared.searchParams.get("program"), "hammer");
    assert.ok(shared.searchParams.getAll("option").includes("scanner:professional"));

    form.elements.speed.value = "4";
    form.dispatchEvent(new window.Event("input", { bubbles: true }));
    assert.equal(new URL(window.location.href).searchParams.get("speed"), "4");
  });

  test("covers pricing models, deck options and cart serializers", () => {
    const browser = installBrowserEnv();
    cleanups.push(browser.cleanup);
    const net = requireFresh("js/netrunning.js");
    assert.equal(net.strengthLabel({ strength: { display: "SPECIAL" } }), "SPECIAL");
    assert.equal(net.strengthLabel({ strength: { base: 4, situational: [{ value: 6, when: "gates" }] } }), "4 (6 gates)");
    assert.equal(net.memoryLabel({ memory: 2 }), "2");
    assert.equal(net.memoryLabel({ memory_model: { label: "Variable MU" } }), "Variable MU");
    assert.match(net.priceLabel({ price: 100, price_qualifier: "approximate" }), /≈ 100\.00 eb/);
    assert.equal(net.priceLabel({ price_model: { label: "AUCTION" } }), "AUCTION");
    assert.equal(net.priceLabel({ price_model: { kind: "not_for_sale" } }), "NOT FOR SALE");
    assert.equal(net.priceLabel({}), "CONTACT FIXER");
    assert.equal(net.isPurchasable({ price: 10 }), true);
    assert.equal(net.isPurchasable({ price: 10, availability: "quote" }), false);

    const builder = {
      chassis: [{
        id: "standard", name: "Standard", price: 100, used_price: 50,
        armor_sp: 0, portable: true, cellular: false, bundled_option_ids: ["bundled"],
      }],
      connections: [{ id: "plug", name: "Plug", price: 10 }],
      limits: { speed: [0, 5], data_wall: [1, 10] },
      base_stats: { cpu: 1, memory: 6, data_wall: 2 },
      upgrades: {
        expanded_memory: { memory: 12, price: 20 },
        speed_per_level: 10,
        data_wall_per_level: 5,
      },
      options: [
        { id: "fixed", name: "Fixed", pricing: "fixed", price: 25, effects: { memory_bonus: 1 } },
        { id: "units", name: "Units", pricing: "per_unit", min: 1, max: 3, price_per_unit: 5, unit: "port" },
        { id: "range", name: "Range", pricing: "range", choices: [{ id: "a", name: "A", price: 2 }, { id: "b", name: "B", price: 7 }] },
        { id: "percent", name: "Percent", pricing: "percentage", percent: 10, effects: { cellular: true } },
        { id: "bundled", name: "Bundled", pricing: "fixed", price: 999 },
        { id: "zero", name: "Zero", pricing: "per_unit", min: 0, max: 2, price_per_unit: 5 },
      ],
    };
    const programs = [
      { id: "multiplier", class_id: "utility", class_ids: ["utility"], strength: { base: 1 }, memory: 2, price: 20, platform: "cyberdeck", deck_effects: { memory_multiplier: 1.5 } },
      { id: "blocked", class_id: "utility", memory: 1, price: 5, platform: "system", loadable: false },
    ];
    const result = net.calculateDeck(builder, programs, {
      chassisId: "missing",
      connectionId: "missing",
      usedStandard: true,
      expandedMemory: true,
      speed: 99,
      dataWall: 0,
      options: { fixed: true, units: 9, range: "b", percent: true, bundled: true, zero: 0 },
      programIds: ["multiplier", "blocked"],
    });
    assert.equal(result.chassis.id, "standard");
    assert.equal(result.connection.id, "plug");
    assert.equal(result.usedStandard, true);
    assert.equal(result.speed, 5);
    assert.equal(result.dataWall, 2);
    assert.equal(result.memory, 19);
    assert.equal(result.cellular, true);
    assert.deepEqual(result.options.map((option) => option.id), ["fixed", "units", "range", "percent"]);

    const programItem = net.createProgramCartItem(programs[0], "Utility");
    assert.equal(programItem.categoryLabel, "Utility");
    const deckItem = net.createDeckCartItem({
      id: "deck", name: "Deck", price: 100, cpu: 1, memory: 10, speed: 2,
      data_wall: 3, armor_sp: 0, portable: true, cellular: false,
      source: { book: "Book" }, reprint_source: { book: "Reprint" },
    });
    assert.equal(deckItem.deckConfiguration.kind, "published");
    const netgear = net.createNetgearCartItem({
      id: "cable", name: "Cable", pricing: "per_unit", price_per_unit: 5,
      min: 1, max: 3, unit: "m",
    }, 99);
    assert.equal(netgear.price, 15);
    assert.equal(netgear.netgear.quantity, 3);
    const custom = net.createCustomDeckCartItem(result);
    assert.equal(custom.deckConfiguration.kind, "custom");
    assert.deepEqual(custom.deckConfiguration.programIds, ["multiplier"]);

    const selected = net.selectProgramsForDeck([
      ...programs,
      { id: "intrusion", class_id: "intrusion", memory: 2, price: 10, platform: "cyberdeck" },
      { id: "expensive", class_id: "protection", memory: 5, price: 1000, platform: "cyberdeck" },
      { id: "conversion", class_id: "utility", memory: 1, price: 1, platform: "cyberdeck", catalog_scope: "netrunner_conversion" },
    ], 4, 50, () => 0);
    assert.deepEqual(new Set(selected.map((item) => item.id)), new Set(["intrusion", "multiplier"]));
  });

  test("reports the Netrunning offline state", async () => {
    const browser = installBrowserEnv({
      html: '<body data-netrunning-page="programs"><p id="net-status"></p></body>',
      fetchImpl: async () => jsonResponse({}, { ok: false, status: 503 }),
    });
    cleanups.push(browser.cleanup);
    requireFresh("js/netrunning.js");
    dispatchDOMContentLoaded(document);
    await flushPromises(5);
    assert.equal(document.body.dataset.netrunningReady, "error");
    assert.match(document.getElementById("net-status").textContent, /offline/i);
  });

  test("rehydrates localized programs and full deck configurations in the cart", async () => {
    const payloads = {
      "cyberwares.pt-BR.json": readJson("data/cyberwares.pt-BR.json"),
      "equipment.pt-BR.json": readJson("data/equipment.pt-BR.json"),
      "decks.pt-BR.json": readJson("data/decks.pt-BR.json"),
      "weapons.pt-BR.json": readJson("data/weapons.pt-BR.json"),
      "ammo.pt-BR.json": readJson("data/ammo.pt-BR.json"),
      "drugs.pt-BR.json": readJson("data/drugs.pt-BR.json"),
      "chip-rates.pt-BR.json": readJson("data/chip-rates.pt-BR.json"),
      "programs.pt-BR.json": readJson("data/programs.pt-BR.json"),
      "cyberdecks.pt-BR.json": readJson("data/cyberdecks.pt-BR.json"),
    };
    const browser = installBrowserEnv({
      url: "https://bytes.test/html/cart.html",
      html: "<div id='cart-list'></div><p id='empty-cart-msg'></p><strong id='cart-total-value'></strong><button id='cart-clear'></button><button id='cart-export'></button>",
      fetchImpl: async (url) => jsonResponse(payloads[path.basename(String(url))]),
    });
    cleanups.push(browser.cleanup);
    window.I18n = {
      getLocale: () => "pt-BR",
      isPtBr: () => true,
      dataPath: (value) => value.replace(".json", ".pt-BR.json"),
      t: (key, _params, fallback) => ({
        "net.custom_deck": "Cyberdeck Personalizado",
        "net.chassis": "CHASSI",
        "net.connection": "CONEXÃO",
        "net.options": "OPÇÕES",
        "net.loaded": "CARREGADOS",
      }[key] || fallback),
    };
    const utils = requireFresh("js/core-utils.js");
    window.CyberUtils = utils;
    global.CyberUtils = utils;
    global.Modal = { confirm() {}, alert() {} };
    global.HackSystem = { init() {} };
    cleanups.push(() => { delete global.Modal; delete global.HackSystem; });
    localStorage.setItem("cyber_cart", JSON.stringify([
      {
        id: "wizards_book",
        name: "Old Wizard",
        sourceCatalog: "programs",
        price: 400,
        hl: 0,
        program: { strength: { base: 4, situational: [] }, memory: 2, platform: "cyberdeck" },
      },
      {
        id: "custom_cyberdeck_test",
        name: "Old Custom",
        sourceCatalog: "cyberdecks",
        price: 12300,
        hl: 0,
        deckConfiguration: {
          kind: "custom",
          chassisId: "standard",
          connectionId: "trodes",
          cpu: 1,
          memory: 20,
          speed: 2,
          dataWall: 4,
          options: [{ id: "video_monitor", quantity: 2 }],
          programIds: ["hammer", "shield"],
          memoryUsed: 2,
        },
      },
    ]));
    requireFresh("js/cart.js");
    dispatchDOMContentLoaded(document);
    await flushPromises(8);
    const cartText = document.getElementById("cart-list").textContent;
    assert.match(cartText, /Grimório/);
    assert.match(cartText, /Cyberdeck Personalizado/);
    assert.match(cartText, /Padrão/);
    assert.match(cartText, /Monitor de Vídeo/);
    assert.match(cartText, /Martelo, Escudo/);
  });
});
