const assert = require("node:assert/strict");
const { afterEach, describe, test } = require("node:test");

const {
  installBrowserEnv,
  requireFresh,
  dispatchDOMContentLoaded,
} = require("./helpers/browser-env.js");

const cleanups = [];

function useBrowser(options) {
  const browser = installBrowserEnv(options);
  cleanups.push(browser.cleanup);
  return browser;
}

function installI18n(locale = "en-US") {
  const api = {
    getLocale: () => locale,
    t: (_key, params, fallback) => String(fallback).replace(/\{(\w+)\}/g, (_match, name) => params[name] ?? `{${name}}`),
  };
  window.I18n = api;
  global.I18n = api;
}

function weapon(id, overrides = {}) {
  return {
    catalog: "weapons",
    id,
    name: `Weapon ${id}`,
    category: "Heavy Handgun",
    description: `Description ${id}`,
    price: 100 + Number(id.replace(/\D/g, "") || 0),
    url: `https://bytes.test/html/weapons.html?item=${id}`,
    stats: [
      { key: "damage", label: "DMG", value: `${id}D6` },
      { key: "accuracy", label: "ACC", value: 0 },
      null,
      { key: "empty", label: "EMPTY", value: "" },
    ],
    ...overrides,
  };
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  for (const key of ["I18n", "CyberComparator", "CyberUtils"]) delete global[key];
});

describe("market comparator", () => {
  test("normalizes storage and enforces one family with a three-item limit", () => {
    useBrowser();
    installI18n();
    const comparator = requireFresh("js/comparator.js");
    dispatchDOMContentLoaded(document);

    assert.equal(comparator.normalizeCandidate(null), null);
    assert.equal(comparator.normalizeCandidate({ catalog: "ammo", id: "x", name: "X" }), null);
    assert.equal(comparator.normalizeCandidate({ catalog: "weapons", id: "", name: "X" }), null);
    assert.deepEqual(comparator.read(), []);
    localStorage.setItem(comparator.STORAGE_KEY, "broken");
    assert.deepEqual(comparator.read(), []);
    localStorage.setItem(comparator.STORAGE_KEY, "{}");
    assert.deepEqual(comparator.read(), []);

    assert.deepEqual(comparator.toggle(null), { ok: false, reason: "invalid" });
    assert.deepEqual(comparator.toggle(weapon("1")), { ok: true, action: "added" });
    assert.equal(comparator.selected("weapons", "1"), true);
    assert.deepEqual(comparator.toggle({ ...weapon("deck"), catalog: "cyberdecks" }), { ok: false, reason: "family" });
    assert.deepEqual(comparator.toggle(weapon("2")), { ok: true, action: "added" });
    assert.deepEqual(comparator.toggle(weapon("3")), { ok: true, action: "added" });
    assert.deepEqual(comparator.toggle(weapon("4")), { ok: false, reason: "full" });
    assert.equal(comparator.current().length, 3);
    assert.deepEqual(comparator.toggle(weapon("2")), { ok: true, action: "removed" });
    assert.equal(comparator.current().length, 2);
    comparator.remove("weapons", "3");
    assert.equal(comparator.current().length, 1);
    assert.equal(comparator.open(), false);
    assert.equal(comparator.close(), false);
    assert.deepEqual(comparator.clear(), []);

    localStorage.setItem(comparator.STORAGE_KEY, JSON.stringify([
      weapon("1"), weapon("1"), { ...weapon("d"), catalog: "cyberdecks" }, weapon("2"), weapon("3"), weapon("4"),
    ]));
    assert.deepEqual(comparator.read().map((item) => item.id), ["1", "2", "3"]);
  });

  test("renders, opens and controls the comparison matrix without touching navigation", () => {
    const { window, document } = useBrowser({
      html: `<!doctype html><html><body><header class="navbar"><nav><ul class="nav-links"><li>HOME</li></ul><div class="language-selector"><select><option>en-US</option></select></div></nav></header>
        <main><button id="origin" data-compare-id="1" data-compare-catalog="weapons" data-compare-label="COMPARE">COMPARE</button>
        <button id="second" data-compare-id="2" data-compare-catalog="weapons" data-compare-label="COMPARE">COMPARE</button></main></body></html>`,
    });
    installI18n();
    requireFresh("js/dialog-a11y.js");
    const updates = [];
    window.addEventListener("comparison-updated", (event) => updates.push(event.detail.items.length));
    const comparator = requireFresh("js/comparator.js");
    dispatchDOMContentLoaded(document);
    comparator.inject();

    assert.ok(document.getElementById("comparison-tray"));
    assert.ok(document.getElementById("comparison-shell"));
    assert.equal(document.querySelector(".navbar [data-comparison-open]"), null);
    assert.equal(document.getElementById("comparison-tray").classList.contains("hidden"), true);
    comparator.syncButton(null);

    comparator.toggle(weapon("1"));
    assert.equal(document.getElementById("origin").getAttribute("aria-pressed"), "true");
    assert.equal(document.getElementById("origin").textContent, "REMOVE");
    assert.equal(document.querySelector("[data-comparison-open]").disabled, true);
    comparator.toggle(weapon("2", {
      price: null,
      description: "",
      stats: [{ key: "range", label: "RNG", value: 50 }],
    }));
    assert.equal(document.querySelector("[data-comparison-open]").disabled, false);
    assert.match(document.getElementById("comparison-matrix").textContent, /NOT LISTED/);
    assert.match(document.getElementById("comparison-matrix").textContent, /DMG/);
    assert.match(document.getElementById("comparison-matrix").textContent, /RNG/);
    assert.match(document.getElementById("comparison-matrix").textContent, /—/);

    const origin = document.getElementById("origin");
    origin.focus();
    document.querySelector("[data-comparison-open]").click();
    const shell = document.getElementById("comparison-shell");
    assert.equal(shell.classList.contains("hidden"), false);
    assert.equal(document.body.classList.contains("compare-open"), true);
    assert.equal(document.activeElement.className, "comparison-close");

    const focusable = shell.querySelectorAll("button, a[href]");
    focusable[0].focus();
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", shiftKey: true, bubbles: true }));
    assert.equal(document.activeElement, focusable[focusable.length - 1]);
    focusable[focusable.length - 1].focus();
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", bubbles: true }));
    assert.equal(document.activeElement, focusable[0]);
    shell.querySelector(".comparison-panel").dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), false);
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), true);
    assert.equal(document.activeElement, origin);

    comparator.open();
    shell.dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), true);
    comparator.open();
    document.querySelector(".comparison-close").click();
    comparator.open();
    document.querySelector(".comparison-item-header button").click();
    assert.equal(comparator.current().length, 1);
    assert.equal(shell.classList.contains("hidden"), true);

    window.dispatchEvent(new window.CustomEvent("comparator-request", { detail: weapon("3") }));
    assert.equal(comparator.current().length, 2);
    window.dispatchEvent(new window.StorageEvent("storage", { key: comparator.STORAGE_KEY }));
    window.dispatchEvent(new window.StorageEvent("storage", { key: null }));
    document.querySelector("[data-comparison-clear]").click();
    assert.deepEqual(comparator.current(), []);
    assert.ok(updates.length >= 4);
  });

  test("skips login pages and supports localized candidates and currency formatters", () => {
    const { document } = useBrowser({ html: "<!doctype html><html><body><div class='login-container'></div></body></html>" });
    installI18n("pt-BR");
    window.CyberUtils = { formatCurrency: (value) => `EB ${value}` };
    global.CyberUtils = window.CyberUtils;
    const comparator = requireFresh("js/comparator.js");
    dispatchDOMContentLoaded(document);
    assert.equal(document.getElementById("comparison-tray"), null);
    assert.equal(comparator.open(), false);
    assert.equal(comparator.close(), false);
    comparator.render();
    comparator.syncButtons();
    const normalized = comparator.normalizeCandidate(weapon("x", {
      category: "",
      price: "25",
      url: "",
      stats: [{ key: "source", value: "Core", label: "" }],
    }));
    assert.equal(normalized.price, 25);
    assert.equal(normalized.category, "weapons");
    assert.equal(normalized.stats[0].label, "source");
  });
});
