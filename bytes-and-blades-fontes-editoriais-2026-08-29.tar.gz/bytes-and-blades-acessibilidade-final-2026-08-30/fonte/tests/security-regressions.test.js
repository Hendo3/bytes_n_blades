const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { test } = require("node:test");
const { JSDOM } = require("jsdom");

const root = path.resolve(__dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("home skip link targets the real main landmark", () => {
  const dom = new JSDOM(read("index.html"));
  const link = dom.window.document.querySelector(".skip-link");
  const target = dom.window.document.querySelector(link.getAttribute("href"));

  assert.equal(link.getAttribute("href"), "#main-content");
  assert.equal(target?.tagName, "MAIN");
  dom.window.close();
});

test("404 source parameter is rendered as text inside strong", () => {
  const attack = '<img src=x onerror="globalThis.pwned=true">';
  const dom = new JSDOM(read("html/404.html"), {
    url: `https://bytes.test/html/404.html?source=${encodeURIComponent(attack)}`,
    runScripts: "outside-only",
  });
  const inlineScript = [...dom.window.document.querySelectorAll("script:not([src])")].at(-1);

  dom.window.eval(inlineScript.textContent);
  const source = dom.window.document.getElementById("error-source");
  assert.equal(source.querySelector("strong").textContent, attack);
  assert.equal(source.querySelector("img"), null);
  assert.equal(dom.window.pwned, undefined);
  dom.window.close();
});

test("all pages that omit modal.js are protected by the auth fallback", () => {
  for (const file of ["html/aptr-chips.html", "html/mram-chips.html", "html/visual-rec-chips.html", "html/404.html"]) {
    const dom = new JSDOM(read(file));
    const scripts = [...dom.window.document.querySelectorAll("script[src]")]
      .map((script) => script.getAttribute("src"));
    assert.ok(scripts.some((source) => source.endsWith("/auth.js")), `${file}: missing auth.js`);
    assert.ok(!scripts.some((source) => source.endsWith("/modal.js")), `${file}: fixture now loads modal.js`);
    dom.window.close();
  }

  const auth = read("js/auth.js");
  assert.match(auth, /activeModal && typeof activeModal\.confirm === "function"/);
  assert.match(auth, /typeof window\.confirm === "function"/);
});

test("maintenance utilities are never part of the public js directory", () => {
  assert.equal(fs.existsSync(path.join(root, "js/fix_hl.js")), false);
  assert.equal(fs.existsSync(path.join(root, "js/fix_costs.js")), false);
  const maintenance = read("scripts/fix-costs.js");
  assert.match(maintenance, /path\.resolve\(__dirname, "\.\.\/data\/cyberwares\.json"\)/);
});
