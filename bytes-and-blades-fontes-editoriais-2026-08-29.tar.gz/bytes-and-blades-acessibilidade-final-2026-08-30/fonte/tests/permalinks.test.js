const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { afterEach, describe, test } = require("node:test");

const {
  projectRoot,
  installBrowserEnv,
  requireFresh,
  flushPromises,
} = require("./helpers/browser-env.js");

const cleanups = [];

function useBrowser(options) {
  const browser = installBrowserEnv(options);
  cleanups.push(browser.cleanup);
  return browser;
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  delete global.CyberPermalinks;
  delete global.I18n;
});

describe("permanent signal links", () => {
  test("creates clean item and filter URLs and restores their state", () => {
    const { window } = useBrowser({ url: "https://bytes.test/html/weapons.html?old=1#noise" });
    const links = requireFresh("js/permalinks.js");

    const itemUrl = new URL(links.catalogItemUrl("weapon_1", {
      smartchipped: true,
      ammoOptionKey: "api_12mm",
      priceModifierKey: "military",
    }));
    assert.equal(itemUrl.pathname, "/html/weapons.html");
    assert.equal(itemUrl.searchParams.get("item"), "weapon_1");
    assert.equal(itemUrl.searchParams.get("smartchip"), "1");
    assert.equal(itemUrl.searchParams.get("ammo"), "api_12mm");
    assert.equal(itemUrl.searchParams.get("modifier"), "military");
    assert.equal(itemUrl.searchParams.has("old"), false);
    assert.equal(itemUrl.hash, "");

    const filterUrl = links.catalogFilterUrl({
      category: "Heavy Handgun",
      price: "500",
      hl: "4",
      cir: "M",
      difficulty: "20",
    });
    assert.deepEqual(links.readCatalogState(new URL(filterUrl)), {
      item: "",
      category: "Heavy Handgun",
      price: "500",
      hl: "4",
      cir: "M",
      difficulty: "20",
      smartchipped: false,
      ammoOptionKey: "",
      priceModifierKey: "",
      level: "",
    });
    assert.equal(links.replace(filterUrl), filterUrl);
    assert.equal(window.location.search, "?category=Heavy+Handgun&price=500&hl=4&cir=M&difficulty=20");

    const programUrl = links.programFilterUrl({
      query: "hammer",
      classId: "intrusion",
      maxPrice: 800,
      includeConversions: true,
    });
    assert.deepEqual(links.readProgramState(programUrl.split("?")[1]), {
      query: "hammer",
      classId: "intrusion",
      maxPrice: "800",
      includeConversions: true,
    });
  });

  test("round-trips a complete deterministic cyberdeck build", () => {
    useBrowser({ url: "https://bytes.test/html/deck-builder.html" });
    const links = requireFresh("js/permalinks.js");
    const selection = {
      chassisId: "standard",
      usedStandard: true,
      expandedMemory: true,
      speed: "4",
      dataWall: "6",
      connectionId: "cellular",
      options: { armor: true, extra_mu: "3", empty: "" },
      programIds: ["hammer", "shield", "hammer"],
    };
    const url = links.builderUrl(selection, true);
    assert.deepEqual(links.readBuilderState(new URL(url)), {
      chassisId: "standard",
      usedStandard: true,
      expandedMemory: true,
      speed: "4",
      dataWall: "6",
      connectionId: "cellular",
      includeConversions: true,
      options: { armor: true, extra_mu: "3" },
      programIds: ["hammer", "shield"],
    });
    assert.equal(links.readBuilderState("?chassis=standard"), null);

    const invalid = new URL(url);
    invalid.searchParams.append("option", "bad key:value");
    invalid.searchParams.append("option", `oversized:${"x".repeat(121)}`);
    invalid.searchParams.append("program", "invalid program");
    for (let index = 0; index < 205; index += 1) invalid.searchParams.append("program", `p_${index}`);
    const decoded = links.readBuilderState(invalid);
    assert.equal(decoded.options["bad key"], undefined);
    assert.equal(decoded.programIds.length, links.MAX_PROGRAMS);
  });

  test("copies with Clipboard API, falls back to execCommand and reports failure", async () => {
    const { window, document } = useBrowser();
    const copied = [];
    Object.defineProperty(window.navigator, "clipboard", {
      configurable: true,
      value: { writeText: async (value) => copied.push(value) },
    });
    const links = requireFresh("js/permalinks.js");
    const button = links.createButton(() => "https://bytes.test/item", "COPY");
    document.body.appendChild(button);
    button.click();
    await flushPromises();
    assert.deepEqual(copied, ["https://bytes.test/item"]);
    assert.equal(button.textContent, "LINK COPIED");

    Object.defineProperty(window.navigator, "clipboard", { configurable: true, value: undefined });
    document.execCommand = () => true;
    assert.equal(await links.copyText("fallback"), "fallback");
    assert.equal(document.querySelector(".permalink-copy-buffer"), null);
    document.execCommand = () => false;
    await assert.rejects(() => links.copyText("blocked"), /Clipboard unavailable/);
    document.execCommand = undefined;
    await assert.rejects(() => links.copyText("missing"), /Clipboard unavailable/);
    button.click();
    await flushPromises();
    assert.equal(button.textContent, "COPY FAILED");
    assert.ok(button.classList.contains("is-error"));
  });

  test("observes chip tables and decorates dynamically rendered rates", async () => {
    const { document } = useBrowser({
      url: "https://bytes.test/html/aptr-chips.html?item=handgun&level=2",
      html: "<div id='chip-rate-groups'></div>",
    });
    const links = requireFresh("js/permalinks.js");
    document.dispatchEvent(new window.Event("DOMContentLoaded", { bubbles: true }));
    const container = document.getElementById("chip-rate-groups");
    container.innerHTML = `<li><span class="controls"><select data-role="chip-level"><option value="1">1</option><option value="2">2</option></select>
      <button data-role="chip-add" data-skill-id="handgun"></button></span></li>`;
    await flushPromises();
    assert.equal(container.querySelectorAll(".btn-share-link").length, 1);
    assert.equal(container.querySelector("select").value, "2");
    assert.ok(container.querySelector("li").classList.contains("search-target"));
    assert.equal(links.enhanceChipRates(container), 0);
    links.observeChipRates();
  });

  test("every route with shareable state loads permalinks before its controller", () => {
    for (const file of [
      "html/cyberwares.html", "html/accessories.html", "html/weapons.html", "html/ammo.html", "html/drugs.html",
      "html/programs.html", "html/cyberdecks.html", "html/deck-builder.html",
      "html/aptr-chips.html", "html/mram-chips.html", "html/visual-rec-chips.html",
    ]) {
      const html = fs.readFileSync(path.join(projectRoot, file), "utf8");
      const permalinks = html.indexOf("../js/permalinks.js");
      const controller = Math.max(html.indexOf("../js/script.js"), html.indexOf("../js/netrunning.js"), html.indexOf("../js/chip-rates.js"));
      assert.ok(permalinks >= 0 && permalinks < controller, file);
    }
  });
});
