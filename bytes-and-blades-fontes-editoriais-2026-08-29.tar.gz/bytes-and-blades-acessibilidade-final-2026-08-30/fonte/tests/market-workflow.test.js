const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { afterEach, describe, test } = require("node:test");

const {
  installBrowserEnv,
  projectRoot,
  requireFresh,
  dispatchDOMContentLoaded,
  jsonResponse,
  flushPromises,
} = require("./helpers/browser-env.js");

const cleanups = [];

function useBrowser(options) {
  const browser = installBrowserEnv(options);
  cleanups.push(browser.cleanup);
  return browser;
}

function interpolate(value, params = {}) {
  return String(value).replace(/\{(\w+)\}/g, (_match, key) => params[key] ?? `{${key}}`);
}

function installI18n(locale = "en-US") {
  const api = {
    isPtBr: () => locale === "pt-BR",
    getLocale: () => locale,
    t: (_key, params, fallback) => interpolate(fallback, params),
    dataPath: (value) => value,
  };
  window.I18n = api;
  global.I18n = api;
  return api;
}

afterEach(() => {
  while (cleanups.length) cleanups.pop()();
  for (const key of ["Modal", "HackSystem", "CyberUtils", "CyberLoadouts", "I18n"] ) delete global[key];
});

describe("local loadout vault", () => {
  test("saves, updates, loads, imports, exports and removes named runs", () => {
    const { window, document } = useBrowser();
    const loadouts = requireFresh("js/loadouts.js");
    let loadoutEvents = 0;
    let stashEvents = 0;
    window.addEventListener("loadouts-updated", () => { loadoutEvents += 1; });
    window.addEventListener("stash-updated", () => { stashEvents += 1; });

    localStorage.setItem(loadouts.LOADOUTS_KEY, "broken");
    assert.deepEqual(loadouts.list(), []);
    assert.equal(loadouts.normalizeName("  NIGHT   CITY  "), "NIGHT CITY");
    assert.equal(loadouts.normalizeName("", "FALLBACK"), "FALLBACK");
    assert.deepEqual(loadouts.current(), []);

    const first = loadouts.save("  SOLO RUN ", [{ id: "gun", name: "Gun", price: 100, hl: 2, cartCount: 2 }], localStorage, new Date("2026-08-28T10:00:00Z"));
    assert.match(first.id, /^loadout_/);
    assert.equal(first.name, "SOLO RUN");
    assert.equal(loadouts.list()[0].items[0].id, "gun");
    const updated = loadouts.save("solo run", [{ id: "armor", price: 500 }], localStorage, new Date("2026-08-28T11:00:00Z"));
    assert.equal(updated.id, first.id);
    assert.equal(loadouts.list().length, 1);
    assert.equal(loadoutEvents, 2);

    assert.equal(loadouts.load("missing"), null);
    const loaded = loadouts.load(first.id);
    assert.equal(loaded.items[0].id, "armor");
    assert.equal(JSON.parse(localStorage.getItem(loadouts.CART_KEY))[0].id, "armor");
    assert.equal(stashEvents, 1);

    const raw = loadouts.parseImport([{ id: "raw" }]);
    assert.equal(raw.name, "IMPORTED RUN");
    const imported = loadouts.importToCart(JSON.stringify({ runner_id: "V", items: [{ id: "chip", price: 20 }] }));
    assert.equal(imported.name, "V");
    assert.equal(stashEvents, 2);
    assert.throws(() => loadouts.parseImport({ nope: true }), /array/);
    assert.throws(() => loadouts.sanitizeItems(Array.from({ length: 1001 }, () => ({}))), /exceeds/);
    assert.deepEqual(loadouts.sanitizeItems([null, [], { id: "ok" }]), [{ id: "ok" }]);

    const payload = loadouts.exportPayload({ name: "SOLO", items: [{ price: 10, hl: 1, cartCount: 3 }] }, "RUNNER", new Date("2026-08-28T12:00:00Z"));
    assert.equal(payload.summary.total_cost, 30);
    assert.equal(payload.summary.total_humanity_loss, 3);
    assert.equal(payload.summary.item_count, 3);

    let clicked = false;
    let revoked = false;
    window.URL.createObjectURL = () => "blob:loadout";
    window.URL.revokeObjectURL = () => { revoked = true; };
    window.HTMLAnchorElement.prototype.click = function click() { clicked = this.download.includes("SOLO"); };
    const downloaded = loadouts.download({ name: "SOLO", items: [] }, "RUNNER", document, new Date("2026-08-28T12:00:00Z"));
    assert.equal(downloaded.name, "SOLO");
    assert.equal(clicked, true);
    assert.equal(revoked, true);

    assert.equal(loadouts.remove("missing"), false);
    assert.equal(loadouts.remove(first.id), true);
    assert.deepEqual(loadouts.list(), []);
  });
});

const searchFixtures = {
  cyberwares: { data: { Neural: { name: "Neural", itens: { eye: { id: "eye", name: "Olho", description: "Visão", price: "100", surg: "M", HL: "1", CIR: "N" } } } } },
  equipment: { data: { tools: { name: "Tools", list: { kit: { id: "kit", name: "Tech Kit", note: "Repair", price: "200" } } } } },
  weapons: { weapons: [{ id: "gun", name: "Gun", Note: "Loud", class: "Pistol", price: 300, damage: "2D6", ammo_type: "9mm", type_code: "P" }] },
  ammo: { items: [{ id: "round", name: "Munição API", description: "Armor piercing", effect: "Burn", category: "Rounds", price: 20, compatibility: "9mm" }] },
  drugs: { data: { street_stock: { items: { stim: { name: "Stim", description: "Alert", effects: "Awake", type: "stimulant", price: "50", strength: "+1", duration: "hour" } } } } },
  programs: { programs: [{ id: "hammer", name: "Hammer", effect: "Break wall", class_ids: ["intrusion"], price: 400, platform: "cyberdeck", icon: "red", availability: "retail" }] },
  cyberdecks: { decks: [{ id: "deck", name: "Deck", description: "Fast", price: 900, memory: 10, speed: 2, source: { book: "Core" } }] },
  chips: { data: { aptr: { label: "APTR", sections: [{ label: "REF", items: [{ id: "handgun", skill: "Handgun", pricePerLevel: 100 }] }] }, mram: { label: "MRAM", sections: [] }, visual_recognition: { label: "Visual", sections: [] } } },
};

describe("global market search", () => {
  test("indexes every real bilingual market feed with stable identity", () => {
    useBrowser();
    installI18n();
    const search = requireFresh("js/global-search.js");
    const read = (name, locale = "") => JSON.parse(fs.readFileSync(path.join(projectRoot, "data", `${name}${locale}.json`), "utf8"));
    const make = (locale = "") => search.buildIndex({
      cyberwares: read("cyberwares", locale),
      equipment: read("equipment", locale),
      weapons: read("weapons", locale),
      ammo: read("ammo", locale),
      drugs: read("drugs", locale),
      programs: read("programs", locale),
      cyberdecks: read("cyberdecks", locale),
      chips: read("chip-rates", locale),
    });
    const english = make();
    const portuguese = make(".pt-BR");
    const identity = (index) => index.map((item) => `${item.catalogId}:${item.id}`).sort();
    assert.equal(english.length, 1584);
    assert.deepEqual(identity(portuguese), identity(english));
    assert.equal(new Set(identity(english)).size, english.length);
    assert.equal(search.searchItems(english, "malorian")[0].name, "Malorian Arms 3516");
    assert.equal(search.searchItems(portuguese, "municao").length, 40);
  });

  test("normalizes and ranks every catalog family", () => {
    useBrowser();
    installI18n();
    const search = requireFresh("js/global-search.js");
    const index = search.buildIndex(searchFixtures);
    assert.equal(index.length, 8);
    assert.equal(search.normalize("Munição ÁPI"), "municao api");
    assert.equal(search.searchItems(index, "gun")[0].id, "gun");
    assert.equal(search.searchItems(index, "9mm", "ammo")[0].id, "round");
    assert.equal(search.searchItems(index, "missing").length, 0);
    assert.equal(search.searchItems(index, "").length, 8);
    assert.equal(search.searchItems(null, "anything").length, 0);
    assert.ok(search.scoreItem(index.find((item) => item.id === "gun"), "pistol") > 0);
    assert.ok(search.scoreItem(index.find((item) => item.id === "gun"), "loud") > 0);
    assert.ok(search.scoreItem(index.find((item) => item.id === "gun"), "gun") > search.scoreItem(index.find((item) => item.id === "round"), "9mm"));

    const fallbacks = search.buildIndex({
      cyberwares: { data: { Other: { items: { blank: { note: "Note" } } } } },
      equipment: { data: { Other: { itens: { spare: { effect: "Effect" } } } } },
      chips: { data: { custom: { label: "Custom", sections: [{ label: "Other", items: [{ id: "free", skill: "Free", levelPrices: [0] }] }] } } },
    });
    assert.equal(fallbacks.length, 3);
    assert.ok(fallbacks.some((item) => item.name === "blank" && item.price === null));
  });

  test("injects the command palette, loads feeds and supports keyboard control", async () => {
    const fileMap = {
      "cyberwares.json": searchFixtures.cyberwares,
      "equipment.json": searchFixtures.equipment,
      "weapons.json": searchFixtures.weapons,
      "ammo.json": searchFixtures.ammo,
      "drugs.json": searchFixtures.drugs,
      "programs.json": searchFixtures.programs,
      "cyberdecks.json": searchFixtures.cyberdecks,
      "chip-rates.json": searchFixtures.chips,
    };
    const { window, document } = useBrowser({
      html: "<!doctype html><html><head></head><body><header class='navbar'><nav><ul></ul></nav></header></body></html>",
      fetchImpl: async (url) => jsonResponse(fileMap[new URL(url).pathname.split("/").pop()]),
    });
    installI18n();
    requireFresh("js/dialog-a11y.js");
    Object.defineProperty(document, "currentScript", { configurable: true, value: { src: "https://bytes.test/js/global-search.js" } });
    window.HTMLElement.prototype.scrollIntoView = () => {};
    const search = requireFresh("js/global-search.js");
    dispatchDOMContentLoaded(document);
    assert.equal(document.querySelectorAll(".global-search-trigger").length, 0);
    search.inject();
    await search.open();
    await flushPromises();
    assert.equal(document.querySelectorAll(".global-search-result").length, 8);
    assert.equal((await search.loadIndex()).length, 8);

    const input = document.getElementById("global-search-input");
    input.value = "hammer";
    input.dispatchEvent(new window.Event("input", { bubbles: true }));
    assert.equal(document.querySelectorAll(".global-search-result").length, 1);
    const select = document.getElementById("global-search-catalog");
    select.value = "weapons";
    select.dispatchEvent(new window.Event("change", { bubbles: true }));
    assert.match(document.getElementById("global-search-results").textContent, /NO SIGNALS/);
    select.value = "";
    input.value = "";
    input.dispatchEvent(new window.Event("input", { bubbles: true }));

    const shell = document.getElementById("global-search-shell");
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }));
    assert.ok(document.querySelector(".global-search-result.is-active"));
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "ArrowUp", bubbles: true }));
    const focusable = shell.querySelectorAll("button, input, select, a[href]");
    focusable[0].focus();
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", shiftKey: true, bubbles: true }));
    assert.equal(document.activeElement, focusable[focusable.length - 1]);
    focusable[focusable.length - 1].focus();
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Tab", bubbles: true }));
    assert.equal(document.activeElement, focusable[0]);
    shell.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), true);
    search.close();

    window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "k", ctrlKey: true, bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), false);
    shell.dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), true);
    window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "/", bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), false);
    input.focus();
    window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "/", bubbles: true }));
    assert.equal(shell.classList.contains("hidden"), false);
    window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "x", bubbles: true }));
    shell.querySelector(".global-search-panel").dispatchEvent(new window.MouseEvent("mousedown", { bubbles: true }));
    document.querySelector(".global-search-close").click();
  });

  test("degrades to an empty index when market feeds fail and skips the login screen", async () => {
    const { document } = useBrowser({
      html: "<!doctype html><html><head></head><body><div class='login-container'></div></body></html>",
      fetchImpl: async () => { throw new Error("offline"); },
    });
    installI18n("pt-BR");
    Object.defineProperty(document, "currentScript", { configurable: true, value: { src: "https://bytes.test/js/global-search.js" } });
    const search = requireFresh("js/global-search.js");
    dispatchDOMContentLoaded(document);
    assert.equal(document.getElementById("global-search-shell"), null);
    assert.deepEqual(await search.loadIndex(), []);
    assert.equal(await search.open(), undefined);
    search.close();
  });

  test("handles unavailable responses and an empty result set outside a navbar", async () => {
    const { window, document } = useBrowser({
      html: "<!doctype html><html><head></head><body><main></main></body></html>",
      fetchImpl: async () => jsonResponse({}, { ok: false, status: 503 }),
    });
    installI18n();
    Object.defineProperty(document, "currentScript", { configurable: true, value: { src: "https://bytes.test/js/global-search.js" } });
    window.HTMLElement.prototype.scrollIntoView = () => {};
    const search = requireFresh("js/global-search.js");
    dispatchDOMContentLoaded(document);
    assert.equal(document.querySelector(".global-search-trigger"), null);
    const first = search.loadIndex();
    const second = search.loadIndex();
    assert.deepEqual(await first, []);
    assert.deepEqual(await second, []);
    await search.open();
    assert.match(document.getElementById("global-search-results").textContent, /NO SIGNALS/);
    document.getElementById("global-search-shell").dispatchEvent(new window.KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }));
    document.getElementById("global-search-results").remove();
    search.renderResults();
  });
});

describe("DataTerm home dashboard", () => {
  test("summarizes the active cart and hydrates market counts", async () => {
    const { window, document } = useBrowser({
      html: `<!doctype html><html><body><section id="dataterm-dashboard">
        <button id="home-global-search"></button><span id="home-loadout-items"></span><span id="home-loadout-cost"></span>
        <span id="home-loadout-hl"></span><span id="home-loadout-saves"></span><span id="home-loadout-state"></span>
        <span id="home-index-total"></span><small data-market-count="weapons"></small></section></body></html>`,
    });
    installI18n();
    localStorage.setItem("cyber_cart", JSON.stringify([{ price: 100, hl: 2, cartCount: 2 }, { price: 50 }]));
    window.CyberLoadouts = { list: () => [{ id: "one" }] };
    let opened = 0;
    window.GlobalSearch = {
      open: () => { opened += 1; },
      loadIndex: async () => [{ catalogId: "weapons" }, { catalogId: "weapons" }, { catalogId: "ammo" }],
    };
    const home = requireFresh("js/home-dashboard.js");
    dispatchDOMContentLoaded(document);
    await flushPromises();
    assert.deepEqual(home.summarize([{ price: 10, hl: 1, cartCount: 3 }]), { lines: 1, items: 3, cost: 30, hl: 3 });
    assert.equal(document.getElementById("home-loadout-items").textContent, "3");
    assert.match(document.getElementById("home-loadout-cost").textContent, /250/);
    assert.equal(document.querySelector("[data-market-count]").textContent, "2 SIGNALS");
    document.getElementById("home-global-search").click();
    assert.equal(opened, 1);
    localStorage.setItem("cyber_cart", "broken");
    window.dispatchEvent(new window.Event("storage"));
    assert.equal(document.getElementById("home-loadout-items").textContent, "0");
    delete window.GlobalSearch;
    assert.deepEqual(await home.renderMarketCounts(document), {});
  });
});

describe("cart loadout controls", () => {
  test("edits line quantity and manages the local vault UI", async () => {
    const { window, document } = useBrowser({
      url: "https://bytes.test/html/cart.html",
      html: `<!doctype html><html><body>
        <div id="cart-list"></div><p id="empty-cart-msg" class="hidden"></p>
        <div><strong id="cart-total-value"></strong><button id="cart-clear"></button><button id="cart-export"></button></div>
        <input id="loadout-name"><button id="loadout-save"></button><input id="loadout-import" type="file">
        <p id="loadout-vault-status"></p><span id="loadout-vault-count"></span><div id="saved-loadouts"></div>
      </body></html>`,
      fetchImpl: async () => jsonResponse({}, { ok: false, status: 500 }),
    });
    installI18n();
    window.CyberUtils = requireFresh("js/core-utils.js");
    global.CyberUtils = window.CyberUtils;
    window.CyberLoadouts = requireFresh("js/loadouts.js");
    global.CyberLoadouts = window.CyberLoadouts;
    let confirmAction;
    global.Modal = { alert() {}, confirm(_title, _message, action) { confirmAction = action; } };
    global.HackSystem = { init() {} };
    localStorage.setItem("cyber_cart", JSON.stringify([{ id: "gun", name: "Gun", price: 100, hl: 1 }]));
    requireFresh("js/cart.js");
    await flushPromises();

    const buttons = document.querySelectorAll(".cart-line-stepper button");
    buttons[1].click();
    assert.equal(JSON.parse(localStorage.getItem("cyber_cart"))[0].cartCount, 2);
    assert.match(document.getElementById("cart-total-value").textContent, /200/);
    document.querySelector(".cart-line-stepper button").click();
    assert.equal(JSON.parse(localStorage.getItem("cyber_cart"))[0].cartCount, 1);

    document.getElementById("loadout-name").value = "SOLO";
    document.getElementById("loadout-save").click();
    assert.equal(document.querySelectorAll(".saved-loadout").length, 1);
    assert.match(document.getElementById("loadout-vault-status").textContent, /SOLO/);

    document.querySelector(".saved-loadout .btn-primary").click();
    assert.equal(typeof confirmAction, "function");
    confirmAction();
    assert.equal(JSON.parse(localStorage.getItem("cyber_cart"))[0].id, "gun");

    let downloaded = false;
    window.CyberLoadouts.download = () => { downloaded = true; };
    document.querySelector(".saved-loadout .btn-secondary").click();
    assert.equal(downloaded, true);
    document.querySelector(".saved-loadout .btn-danger").click();
    confirmAction();
    assert.equal(document.querySelectorAll(".saved-loadout").length, 0);

    const importInput = document.getElementById("loadout-import");
    Object.defineProperty(importInput, "files", { configurable: true, value: [{ text: async () => JSON.stringify({ name: "IMPORTED", items: [{ id: "ammo", price: 5 }] }) }] });
    importInput.dispatchEvent(new window.Event("change", { bubbles: true }));
    await flushPromises();
    assert.equal(JSON.parse(localStorage.getItem("cyber_cart"))[0].id, "ammo");

    Object.defineProperty(importInput, "files", { configurable: true, value: [{ text: async () => "{" }] });
    importInput.dispatchEvent(new window.Event("change", { bubbles: true }));
    await flushPromises();
    assert.equal(document.getElementById("loadout-vault-status").classList.contains("is-error"), true);

    localStorage.setItem("cyber_cart", "[]");
    document.getElementById("loadout-save").click();
    assert.match(document.getElementById("loadout-vault-status").textContent, /EMPTY/);
  });
});

describe("search deep links", () => {
  test("reveals and focuses optional Netrunning conversions", async () => {
    const programs = {
      classes: [{ id: "intrusion", label: "Intrusion" }],
      programs: [{
        id: "optional-program", name: "Optional", effect: "Test", class_ids: ["intrusion"], class_id: "intrusion",
        catalog_scope: "netrunner_conversion", platform: "cyberdeck", memory: 1, price: 100,
        price_model: { kind: "fixed", amount: 100 }, availability: "retail", strength: { base: 1 },
        source: { book: "Test", pages: "1" },
      }],
    };
    const decks = { decks: [], builder: { external_products: [] } };
    let calls = 0;
    const { window, document } = useBrowser({
      url: "https://bytes.test/html/programs.html?item=optional-program&q=Optional&class=intrusion&price=200&conversions=1",
      html: `<!doctype html><html><body><main data-netrunning-page><div class="net-filters"><select id="program-class"></select><input id="program-search"><input id="program-price">
        <input id="program-conversions" type="checkbox"></div><span id="program-count"></span><div id="program-list"></div></main></body></html>`,
      fetchImpl: async () => jsonResponse(calls++ === 0 ? programs : decks),
    });
    installI18n();
    requireFresh("js/permalinks.js");
    window.HTMLElement.prototype.scrollIntoView = () => {};
    requireFresh("js/netrunning.js");
    dispatchDOMContentLoaded(document);
    await flushPromises();
    assert.equal(document.getElementById("program-conversions").checked, true);
    assert.equal(document.getElementById("program-search").value, "Optional");
    assert.equal(document.getElementById("program-class").value, "intrusion");
    assert.equal(document.getElementById("program-price").value, "200");
    assert.ok(document.querySelector("[data-share-program-filter]"));
    assert.equal(document.querySelector("[data-item-id='optional-program']").classList.contains("search-target"), true);
  });

  test("reveals and focuses optional published decks", async () => {
    const programs = { classes: [], programs: [] };
    const decks = {
      decks: [{
        id: "optional-deck", name: "Optional Deck", description: "Test", catalog_scope: "netrunner_conversion",
        cpu: 1, memory: 10, speed: 2, data_wall: 3, options: [], price: 1000,
        price_model: { kind: "fixed", amount: 1000 }, availability: "retail", source: { book: "Test", pages: "1" },
      }],
      builder: { external_products: [] },
    };
    let calls = 0;
    const { window, document } = useBrowser({
      url: "https://bytes.test/html/cyberdecks.html?item=optional-deck&conversions=1",
      html: `<!doctype html><html><body><main data-netrunning-page><label><input id="deck-conversions" type="checkbox"></label><span id="deck-count"></span>
        <div id="deck-list"></div><div id="netgear-list"></div></main></body></html>`,
      fetchImpl: async () => jsonResponse(calls++ === 0 ? programs : decks),
    });
    installI18n();
    requireFresh("js/permalinks.js");
    window.HTMLElement.prototype.scrollIntoView = () => {};
    requireFresh("js/netrunning.js");
    dispatchDOMContentLoaded(document);
    await flushPromises();
    assert.equal(document.getElementById("deck-conversions").checked, true);
    assert.equal(document.querySelector("[data-item-id='optional-deck']").classList.contains("search-target"), true);
  });
});
