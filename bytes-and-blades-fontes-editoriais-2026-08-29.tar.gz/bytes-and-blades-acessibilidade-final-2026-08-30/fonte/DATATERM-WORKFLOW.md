# DataTerm Market Workflow

## Busca global

- Atalhos: `Ctrl+K`, `Cmd+K` ou `/` fora de campos de formulário.
- 1.584 sinais indexados em `en-US` e `pt-BR` com os mesmos IDs.
- Feeds: Ciberware, Equipamentos, Armas, Munições, Drogas, Programas, Ciberterminais e Chips de Perícia.
- Busca tolerante a acentos, com filtro por feed e navegação por teclado.
- Resultados de catálogo abrem e destacam diretamente o item solicitado.
- Nas páginas internas, os dados são carregados apenas quando a busca é aberta; a home carrega o índice para exibir as contagens dos mercados.
- Nenhum botão de busca é injetado no menu: o acesso global fica nos atalhos e no console da home.

## Comparador de mercado

- Disponível em Armas, Ciberware, Programas e Cyberdecks.
- Aceita de dois a três itens por comparação.
- Mantém somente uma família por vez para que todas as linhas permaneçam mecanicamente comparáveis.
- A seleção fica em `cyber_comparison` e sobrevive à navegação entre páginas.
- Cada coluna inclui preço, categoria, descrição, estatísticas próprias e link para o item de origem.
- A matriz se ajusta à viewport sem criar rolagem horizontal na página.

## Painel inicial

- Resumo do loadout ativo: itens, custo, Perda de Humanidade e saves locais.
- Diretório completo de mercados com contagem dos sinais carregados.
- Acesso direto a Bundles, construtor de cyberdeck, carrinho e busca global.

## Cofre de loadouts

- Armazenamento local em `cyber_loadouts`.
- Nomes de até 48 caracteres.
- Salvar novamente com o mesmo nome atualiza o registro existente.
- Carregar substitui o carrinho somente após confirmação.
- Importação aceita o JSON exportado pelo site ou um array legado de itens.
- Exportação usa o formato `bytes-and-blades-loadout-v1`.
- Limite defensivo de 1.000 itens por arquivo importado.

## Quantidade no carrinho

O campo `cartCount` representa a multiplicidade da linha no carrinho. Ele é separado do campo `quantity` já usado por Bundles, cabos, opções de cyberdeck e outros itens com quantidade mecânica interna.

Preço, Perda de Humanidade, descontos de Bundle, avisos de consistência e JSON exportado consideram `cartCount`.

## Proteções

- Nenhum estilo inline permanece em `js/cart.js`.
- O carrinho usa apenas as variáveis tipográficas globais Mokoto.
- Catálogos e dados bilíngues não foram modificados.
- A identidade dos 1.584 resultados é verificada automaticamente entre os dois idiomas.
- O cabeçalho não contém o gatilho visual da busca e mantém o seletor de idioma dentro da viewport.
