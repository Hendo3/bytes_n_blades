# Editorial source contract

The site resolves catalog IDs through `data/editorial-sources.json`. Mechanical catalog files remain untouched, including the protected Cyberware and Chip datasets.

## Citation policy

- `Weapons Listing v5` and `Ammunition & Add-ons` are unofficial consolidation indexes. They may identify candidates, but the UI never presents them as editorial sources.
- `page` means an item occurrence was checked on an official PDF page.
- `section` means the official page range was checked as a section-level reference.
- `book` means the official book is identified but its page was not confirmed in the supplied files.
- `unverified` is rendered explicitly. The interface must not infer or invent a page.

## Current coverage

- Weapons: 184 page-level references in *Blackhand's Street Weapons 2020*.
- Ammo & Add-ons: all 336 records have an explicit source state; official reprint sections, original books and unresolved records are distinguished.
- Cyberware: all 563 records have an explicit source state; Corebook sections and Chromebook pages are resolved without changing `cyberwares.json`.
- Programs and cyberdecks continue to use their existing item-level official sources.

The same resolver supplies catalog cards, global search, the cart and comparator. The source registry is also part of the offline precache.
