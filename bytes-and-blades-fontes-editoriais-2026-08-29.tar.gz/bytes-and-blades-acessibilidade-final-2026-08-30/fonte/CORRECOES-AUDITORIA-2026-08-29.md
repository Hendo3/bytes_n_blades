# Correções da auditoria

Base: Bytes & Blades com comparador, busca global, loadouts e navegação responsiva.

## Correções aplicadas

- `JACK OUT` usa `Modal.confirm` quando disponível e confirmação nativa como fallback.
- O skip-link da home aponta para o `<main id="main-content">` existente.
- A página 404 renderiza o parâmetro `source` por DOM e `textContent`, sem interpolação em `innerHTML`.
- `fix_hl.js` foi removido por ser um utilitário obsoleto sem dados de origem válidos.
- `fix_costs.js` virou `scripts/fix-costs.js`, fora do build público e com caminho absoluto baseado em `__dirname`.
- O console de debug ganhou uma verificação conjunta dos 18 datasets EN/PT-BR.
- Os mapas legados de modificadores de equipment PT-BR preservam as mesmas chaves estáveis do EN.
- A suíte compara a estrutura dos nove pares de catálogos localizados e valida explicitamente os campos editoriais adicionais do Cyberware PT-BR.

## Gate final

- 146 testes aprovados.
- Cobertura: 99,45% de linhas, 81,01% de branches e 96,18% de funções.
- 18 datasets validados.
- 72 arquivos no build estático.
